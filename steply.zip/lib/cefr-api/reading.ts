// PRACTICE — Reading. Talaba o'z Steply login sessiyasi bilan ishlaydi.
// Endpointlar: GET /reading-tests, GET /reading-tests/{id}, POST /reading-tests/{id}/submit
// (exams-auth / /exams/* ishlatilmaydi — u faqat mock imtihon portali uchun).
import { readingApi } from '@/lib/api'
import type { ReadingResultDetail } from '@/lib/api/types'
import type { ReadingExam } from '@/lib/cefr-types/reading'

export interface AnswerItem {
  question_id: number
  answers: string[]
}

export interface ReadingSubmission {
  answers: AnswerItem[]
  exam_attempt_id?: number | null
}

export const getAllReadingExamsAPI = async () => {
  return { data: (await readingApi.getAll()) as unknown as ReadingExam[] }
}

export const getReadingExamByIdAPI = async (testId: string) => {
  if (!testId) throw new Error('testId is required')
  return { data: (await readingApi.get(testId)) as unknown as ReadingExam }
}

export const submitReadingExamAPI = async (testId: string, data: ReadingSubmission) => {
  if (!testId) throw new Error('testId is required')
  return { data: (await readingApi.submit(testId, data)) as ReadingResultDetail }
}
