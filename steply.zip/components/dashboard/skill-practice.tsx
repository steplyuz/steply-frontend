'use client'
/* eslint-disable @typescript-eslint/no-explicit-any */

import type { ReactNode } from 'react'
import Link from 'next/link'
import { ArrowLeft, ArrowRight, BookOpenText, CheckCircle2, Clock3, Headphones, Play, Sparkles } from 'lucide-react'
import { useApi } from '@/lib/api/use-api'
import { Badge, Empty, ErrorBox, Loading, btn, fmtDate } from './ui'

export type TestCard = { id: string; title: string; meta: (string | null | undefined)[]; free?: boolean }
export type ResultRow = { id: number; date: string; score: string; level?: string | null; note?: string | null }

export function SkillPractice(props: {
  title: string
  desc: string
  listPath: string
  resultsPath: string
  testBaseHref?: string
  toTest: (raw: any) => TestCard
  toResult: (raw: any) => ResultRow
  resultAction?: (id: number, reload: () => void) => ReactNode
  /** Hero'dan keyin ko'rsatiladigan ixtiyoriy blok (masalan, obuna ogohlantirishi). */
  notice?: ReactNode
  /** Natijalardan keyin ko'rsatiladigan ixtiyoriy blok. */
  footer?: ReactNode
  /** Start huquqi: 'loading' — hali aniqlanmagan, 'locked' — lockedAction ko'rsatiladi. Default 'open'. */
  accessState?: 'loading' | 'open' | 'locked'
  /** accessState 'locked' bo'lganda "Boshlash" o'rniga ko'rsatiladigan amallar. */
  lockedAction?: (t: TestCard) => ReactNode
}) {
  const { title, desc, listPath, resultsPath, testBaseHref, toTest, toResult, resultAction, notice, footer, accessState = 'open', lockedAction } = props
  const tests = useApi<any[]>(listPath)
  const results = useApi<any[]>(resultsPath)
  const isListening = title.toLowerCase() === 'listening'
  const SkillIcon = isListening ? Headphones : BookOpenText

  return (
    <div className="space-y-8 sm:space-y-10">
      <div className="flex items-center justify-between gap-3">
        <Link href="/dashboard" className="inline-flex min-h-10 items-center gap-2 rounded-xl px-3 text-sm font-semibold text-muted-foreground transition hover:bg-white hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-foreground/20">
          <ArrowLeft className="size-4" /> Kabinetga qaytish
        </Link>
        <span className="hidden items-center gap-1.5 rounded-full border border-border bg-white px-3 py-1.5 text-xs font-medium text-muted-foreground sm:inline-flex">
          <Sparkles className="size-3.5 text-foreground" /> Steply Practice
        </span>
      </div>

      <section className="relative isolate overflow-hidden rounded-2xl border border-border bg-white p-5 shadow-[0_8px_28px_rgba(11,11,13,0.035)] sm:p-7 lg:p-8">
        <div aria-hidden="true" className="absolute -right-12 -top-16 -z-10 size-64 rounded-full bg-[#E4F70A]/25 blur-3xl" />
        <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="max-w-2xl">
            <div className="mb-4 inline-flex size-12 items-center justify-center rounded-2xl bg-[#E4F70A] text-foreground">
              <SkillIcon className="size-6" strokeWidth={2.1} />
            </div>
            <p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-muted-foreground">Ko‘nikma mashqi</p>
            <h1 className="text-3xl font-bold tracking-[-0.04em] text-foreground sm:text-4xl">{title}</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-muted-foreground sm:text-base">{desc}. Darajangizga mos testni tanlang va natijalaringizni kuzatib boring.</p>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:min-w-52 sm:grid-cols-1">
            <div className="rounded-xl border border-border/70 bg-background p-4">
              <p className="text-xs font-medium text-muted-foreground">Mavjud testlar</p>
              <p className="mt-1 text-2xl font-bold tracking-tight text-foreground">{tests.loading ? '—' : tests.data?.length ?? 0}</p>
            </div>
            <div className="rounded-xl border border-border/70 bg-background p-4">
              <p className="text-xs font-medium text-muted-foreground">Yakunlangan</p>
              <p className="mt-1 text-2xl font-bold tracking-tight text-foreground">{results.loading ? '—' : results.data?.length ?? 0}</p>
            </div>
          </div>
        </div>
      </section>

      {notice}

      <section aria-labelledby="available-tests-heading" className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Mashqni boshlang</p>
            <h2 id="available-tests-heading" className="mt-1 text-xl font-bold tracking-tight sm:text-2xl">Testlar katalogi</h2>
          </div>
          {!tests.loading && !tests.error && <span className="rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-muted-foreground ring-1 ring-border">{tests.data?.length ?? 0} ta test</span>}
        </div>
        {tests.loading ? <Loading rows={2} /> : tests.error ? (
          <ErrorBox message={tests.error.message} onRetry={tests.reload} />
        ) : !tests.data?.length ? (
          <div className="rounded-2xl border border-dashed border-border bg-white px-5 py-12 text-center">
            <div className="mx-auto flex size-12 items-center justify-center rounded-2xl bg-background"><SkillIcon className="size-5 text-muted-foreground" /></div>
            <p className="mt-4 text-sm font-semibold text-foreground">Hozircha testlar yo‘q.</p>
            <p className="mt-1 text-sm text-muted-foreground">Yangi testlar qo‘shilganda shu yerda ko‘rinadi.</p>
          </div>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {tests.data.map((raw) => {
              const t = toTest(raw)
              return (
                <article key={t.id} className="group flex min-h-56 flex-col justify-between rounded-2xl border border-border bg-white p-5 shadow-[0_4px_16px_rgba(11,11,13,0.02)] transition duration-200 hover:-translate-y-0.5 hover:border-foreground/20 hover:shadow-[0_12px_28px_rgba(11,11,13,0.06)] sm:p-6">
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex size-10 items-center justify-center rounded-xl bg-background text-foreground transition-colors group-hover:bg-[#E4F70A]"><SkillIcon className="size-5" /></div>
                      {t.free && <Badge tone="green">Bepul</Badge>}
                    </div>
                    <h3 className="mt-4 line-clamp-2 text-base font-bold leading-6 text-foreground">{t.title}</h3>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {t.meta.filter(Boolean).map((meta, index) => (
                        <span key={`${meta}-${index}`} className="inline-flex items-center gap-1.5 rounded-lg bg-background px-2.5 py-1.5 text-xs font-medium text-muted-foreground">
                          {index === 1 ? <Clock3 className="size-3.5" /> : null}{meta}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mt-6 flex items-center justify-between gap-3 border-t border-border pt-4">
                    <span className="text-xs font-medium text-muted-foreground">Mashq testi</span>
                    {accessState === 'locked' ? (lockedAction ? lockedAction(t) : null) : accessState === 'loading' ? null : testBaseHref && (
                      <Link href={`${testBaseHref}/${t.id}`} className={`${btn.primary} inline-flex items-center gap-2 min-h-10 rounded-xl px-4 text-sm font-semibold`}>
                        <Play className="size-3.5 fill-current" /> Boshlash <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-0.5" />
                      </Link>
                    )}
                  </div>
                </article>
              )
            })}
          </div>
        )}
      </section>

      <section aria-labelledby="practice-results-heading" className="space-y-4">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">O‘sishingiz</p>
            <h2 id="practice-results-heading" className="mt-1 text-xl font-bold tracking-tight sm:text-2xl">Mening natijalarim</h2>
          </div>
          <span className="hidden items-center gap-1.5 text-xs font-medium text-muted-foreground sm:flex"><CheckCircle2 className="size-4" /> Test yakunlari</span>
        </div>
        {results.loading ? <Loading rows={2} /> : results.error ? (
          <ErrorBox message={results.error.message} onRetry={results.reload} />
        ) : !results.data?.length ? (
          <div className="rounded-2xl border border-border bg-white p-8 text-center shadow-[0_4px_16px_rgba(11,11,13,0.02)]"><Empty text="Hali natija yo‘q." /><p className="mt-1 text-sm text-muted-foreground">Birinchi testni yakunlaganingizdan so‘ng natijangiz shu yerda chiqadi.</p></div>
        ) : (
          <div className="overflow-hidden rounded-2xl border border-border bg-white">
            {results.data.map((raw, index) => {
              const r = toResult(raw)
              return (
                <div key={r.id} className={`flex flex-wrap items-center justify-between gap-4 p-4 sm:px-6 ${index ? 'border-t border-border' : ''}`}>
                  <div className="flex min-w-0 items-center gap-3 sm:gap-4">
                    <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-background text-foreground"><CheckCircle2 className="size-5" /></div>
                    <div className="min-w-0"><p className="truncate font-semibold text-foreground">{fmtDate(r.date)}</p><p className="mt-1 text-xs text-muted-foreground">{r.note || 'Test yakunlandi'}</p></div>
                  </div>
                  <div className="flex items-center gap-3 sm:gap-4"><div className="text-right"><p className="text-xl font-bold tabular-nums text-foreground">{r.score}</p><p className="text-[11px] text-muted-foreground">ball</p></div>{r.level && <Badge tone="primary">{r.level}</Badge>}{resultAction?.(r.id, results.reload)}</div>
                </div>
              )
            })}
          </div>
        )}
      </section>

      {footer}
    </div>
  )
}
