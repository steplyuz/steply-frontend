"use client"

import { useState, useRef, useEffect, useLayoutEffect } from "react"
import { createPortal } from "react-dom"
import { ChevronDown, Check, LayoutList, X } from "lucide-react"
import type { Question } from "@/lib/cefr-types/reading"

interface QuestionRendererProps {
    question: Question
    answer: string
    onAnswer: (value: string) => void
    onInputChange: (value: string) => void
    fontSize?: number
}

/** Foydalanuvchi tanlagan matn o'lchamini variantlarga ham qo'llaymiz (oldin 15px bilan kesilgan edi). */
const optionFont = (fs: number) => Math.min(Math.max(fs - 2, 14), 17)

// ----------------------------------------------------------------------
// Umumiy radio-variant
// ----------------------------------------------------------------------
function RadioOption({
    selected, onClick, children, fontSize = 16,
}: {
    selected: boolean
    onClick: () => void
    children: React.ReactNode
    fontSize?: number
}) {
    return (
        <button
            type="button"
            role="radio"
            aria-checked={selected}
            onClick={(e) => { e.stopPropagation(); onClick() }}
            className={`flex min-h-12 w-full items-center gap-2.5 rounded-xl border px-3 py-2.5 text-left transition-all duration-200
                ${selected
                    ? "border-transparent bg-foreground/[0.12] shadow-[0_8px_24px_rgba(0,0,0,0.08)]"
                    : "border-border bg-white hover:border-foreground/40 hover:bg-foreground/[0.04]"}`}
        >
            <span
                className={`relative size-5 shrink-0 rounded-full transition-all duration-200 ${selected ? "border border-foreground bg-white" : "bg-[#d9d9d9]"}`}
                aria-hidden
            >
                <span className={`absolute inset-0 m-auto size-2.5 rounded-full bg-foreground transition-transform duration-200 ${selected ? "scale-100" : "scale-0"}`} />
            </span>
            <span className="min-w-0 flex-1 break-words leading-snug text-foreground" style={{ fontSize: `${optionFont(fontSize)}px` }}>
                {children}
            </span>
        </button>
    )
}

// ----------------------------------------------------------------------
// 1. TRUE / FALSE / NOT GIVEN
// ----------------------------------------------------------------------
export function TrueFalseNotGivenRenderer({
    answer,
    onAnswer,
    fontSize = 16,
}: {
    answer: string
    onAnswer: (value: string) => void
    fontSize?: number
}) {
    const options = [
        { label: "TRUE", value: "A" },
        { label: "FALSE", value: "B" },
        { label: "NOT GIVEN", value: "C" },
    ]

    return (
        <div role="radiogroup" className="w-full space-y-2">
            {options.map((option) => {
                const isActive = answer === option.value
                return (
                    <RadioOption
                        key={option.value}
                        selected={isActive}
                        // Qayta bosilsa javob bekor qilinadi
                        onClick={() => onAnswer(isActive ? "" : option.value)}
                        fontSize={fontSize}
                    >
                        <span className={isActive ? "font-semibold" : ""}>{option.label}</span>
                    </RadioOption>
                )
            })}
        </div>
    )
}

// ----------------------------------------------------------------------
// 2. MULTIPLE CHOICE
// Eslatma: bu yerda value = harf (A/B/C), label = variant matni.
// Javob sifatida MATN (label) saqlanadi. Backend ham matn bilan solishtirishi shart.
// ----------------------------------------------------------------------
export function MultipleChoiceRenderer({
    question,
    answer,
    onAnswer,
    fontSize = 16,
}: {
    question: Question
    answer: string
    onAnswer: (value: string) => void
    fontSize?: number
}) {
    return (
        <div role="radiogroup" className="w-full max-w-full space-y-2">
            {question.options?.map((option) => {
                // Saqlangan javob harf ko'rinishida qaytsa ham tanlangan holat to'g'ri ko'rinadi
                const isSelected = !!answer && (answer === option.label || answer === option.value)
                return (
                    <RadioOption
                        key={option.value}
                        selected={isSelected}
                        onClick={() => onAnswer(isSelected ? "" : option.label)}
                        fontSize={fontSize}
                    >
                        <span className="mr-1.5 font-bold text-foreground">{option.value}.</span>
                        <span className={isSelected ? "font-semibold" : ""}>{option.label}</span>
                    </RadioOption>
                )
            })}
        </div>
    )
}

// ----------------------------------------------------------------------
// 3. GAP FILL (matn kiritish)
// ----------------------------------------------------------------------
export function GapFillFillRenderer({
    answer,
    onInputChange,
    fontSize = 16,
    inputRef,
}: {
    answer: string
    onInputChange: (value: string) => void
    fontSize?: number
    /** Savol tanlanganda inputga fokus berish uchun (Part 5). */
    inputRef?: React.Ref<HTMLInputElement>
}) {
    return (
        <div className="w-full max-w-full">
            <input
                ref={inputRef}
                type="text"
                placeholder="Javobni yozing..."
                value={answer ?? ""}
                onChange={(e) => onInputChange(e.target.value)}
                onClick={(e) => e.stopPropagation()}
                autoComplete="off"
                spellCheck={false}
                className="h-12 w-full min-w-0 rounded-xl border border-border bg-white px-3.5 font-medium text-foreground outline-none transition-all placeholder:text-muted-foreground/70 focus:border-foreground focus:ring-4 focus:ring-foreground/10"
                style={{ fontSize: `${optionFont(fontSize)}px` }}
            />
        </div>
    )
}

// ----------------------------------------------------------------------
// 4. SELECT (TEXT_MATCH / HEADINGS_MATCH) — portal dropdown
// ----------------------------------------------------------------------
export function SelectRenderer({
    question,
    answer,
    onAnswer,
    fontSize = 16,
    placeholder = "Tanlang...",
}: {
    question: Question
    answer: string
    onAnswer: (value: string) => void
    fontSize?: number
    placeholder?: string
}) {
    const [isOpen, setIsOpen] = useState(false)
    const [menuStyle, setMenuStyle] = useState<React.CSSProperties>({})
    const buttonRef = useRef<HTMLButtonElement>(null)
    const menuRef = useRef<HTMLDivElement>(null)

    const selectedOption = question.options?.find((opt) => opt.value === answer)

    const updatePosition = () => {
        if (!buttonRef.current) return
        const rect = buttonRef.current.getBoundingClientRect()
        const viewportHeight = window.innerHeight
        const viewportWidth = window.innerWidth
        const spaceBelow = viewportHeight - rect.bottom
        const menuHeight = Math.min((question.options?.length || 0) * 44 + 44, 320)
        const opensUpwards = spaceBelow < menuHeight + 10 && rect.top > spaceBelow

        setMenuStyle({
            position: "fixed",
            left: `${rect.left}px`,
            width: `${rect.width}px`,
            maxWidth: `${viewportWidth - 20}px`,
            top: opensUpwards ? "auto" : `${rect.bottom + 6}px`,
            bottom: opensUpwards ? `${viewportHeight - rect.top + 6}px` : "auto",
            zIndex: 99999,
        })
    }

    useLayoutEffect(() => {
        if (!isOpen) return
        updatePosition()
        // Menyuning o'z ichidagi scroll pozitsiyani qayta hisoblamasin
        const onScroll = (e: Event) => {
            if (menuRef.current?.contains(e.target as Node)) return
            updatePosition()
        }
        // capture: scroll hodisasi bubbling qilmaydi
        window.addEventListener("scroll", onScroll, { capture: true })
        window.addEventListener("resize", updatePosition)
        return () => {
            window.removeEventListener("scroll", onScroll, { capture: true })
            window.removeEventListener("resize", updatePosition)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isOpen])

    useEffect(() => {
        if (!isOpen) return
        const onDown = (event: MouseEvent) => {
            const t = event.target as Node
            if (menuRef.current?.contains(t) || buttonRef.current?.contains(t)) return
            setIsOpen(false)
        }
        const onKey = (e: KeyboardEvent) => {
            if (e.key === "Escape") {
                setIsOpen(false)
                buttonRef.current?.focus()
            }
        }
        document.addEventListener("mousedown", onDown)
        document.addEventListener("keydown", onKey)
        return () => {
            document.removeEventListener("mousedown", onDown)
            document.removeEventListener("keydown", onKey)
        }
    }, [isOpen])

    const pick = (value: string) => {
        onAnswer(value)
        setIsOpen(false)
        buttonRef.current?.focus()
    }

    const DropdownMenu = (
        <div
            ref={menuRef}
            role="listbox"
            className="flex flex-col overflow-hidden rounded-xl border border-border bg-white shadow-2xl animate-in fade-in zoom-in-95 duration-100"
            style={{ ...menuStyle, maxHeight: "320px" }}
        >
            {answer && (
                <div className="flex justify-end border-b border-border bg-background/70 px-2 py-1.5">
                    <button
                        type="button"
                        onClick={(e) => {
                            e.stopPropagation()
                            pick("")
                        }}
                        className="flex items-center gap-1 rounded px-2 py-0.5 text-[11px] font-semibold text-red-500 transition-colors hover:bg-red-50 hover:text-red-600"
                    >
                        <X size={11} /> Tozalash
                    </button>
                </div>
            )}

            <div className="space-y-0.5 overflow-y-auto p-1">
                {question.options?.map((option) => {
                    const isSelected = answer === option.value
                    return (
                        <div
                            key={option.value}
                            role="option"
                            tabIndex={0}
                            aria-selected={isSelected}
                            onClick={() => pick(option.value)}
                            onKeyDown={(e) => {
                                if (e.key === "Enter" || e.key === " ") {
                                    e.preventDefault()
                                    pick(option.value)
                                }
                            }}
                            className={`grid cursor-pointer grid-cols-[auto_1fr] gap-2.5 rounded-lg border px-2.5 py-2 outline-none transition-colors focus-visible:border-foreground
                                ${isSelected ? "border-foreground/25 bg-foreground/10" : "border-transparent hover:bg-background"}`}
                        >
                            <div
                                className={`mt-0.5 flex size-5 items-center justify-center rounded-md border text-[10px] font-bold transition-colors
                                    ${isSelected ? "border-[#E4F70A] bg-[#E4F70A] text-foreground" : "border-border bg-background text-muted-foreground"}`}
                            >
                                {isSelected ? <Check size={11} strokeWidth={3} /> : option.value}
                            </div>
                            <span
                                className={`block min-w-0 break-words leading-snug ${isSelected ? "font-bold text-foreground" : "font-medium text-muted-foreground"}`}
                                style={{ fontSize: `${optionFont(fontSize)}px` }}
                            >
                                {option.label}
                            </span>
                        </div>
                    )
                })}
            </div>
        </div>
    )

    return (
        <>
            <div className="relative w-full max-w-full">
                <button
                    type="button"
                    ref={buttonRef}
                    onClick={(e) => { e.stopPropagation(); setIsOpen((v) => !v) }}
                    onKeyDown={(e) => {
                        if ((e.key === "ArrowDown" || e.key === "ArrowUp") && !isOpen) {
                            e.preventDefault()
                            setIsOpen(true)
                        }
                    }}
                    aria-haspopup="listbox"
                    aria-expanded={isOpen}
                    className={`flex min-h-[58px] w-full items-center gap-3 rounded-xl border bg-white px-3.5 py-2 text-left transition-all duration-150
                        ${isOpen
                            ? "border-foreground ring-4 ring-foreground/10"
                            : selectedOption
                                ? "border-foreground/50"
                                : "border-border hover:border-foreground/40"}`}
                >
                    <LayoutList size={18} className="shrink-0 text-foreground" />
                    <div className="min-w-0 flex-1 overflow-hidden">
                        <span className="block text-[11px] font-semibold leading-none text-muted-foreground">Javobni tanlang</span>
                        {selectedOption ? (
                            <div className="mt-1.5 flex items-center gap-2">
                                <span className="flex size-5 shrink-0 items-center justify-center rounded-md bg-foreground text-[10px] font-bold text-white">
                                    {selectedOption.value}
                                </span>
                                <span
                                    className="block truncate font-semibold text-foreground"
                                    style={{ fontSize: `${optionFont(fontSize)}px` }}
                                    title={selectedOption.label}
                                >
                                    {selectedOption.label}
                                </span>
                            </div>
                        ) : (
                            <span className="mt-1.5 block truncate text-sm font-medium text-muted-foreground/70">{placeholder}</span>
                        )}
                    </div>
                    <ChevronDown
                        size={16}
                        className={`shrink-0 text-muted-foreground/70 transition-transform duration-200 ${isOpen ? "rotate-180 text-foreground" : ""}`}
                    />
                </button>
            </div>

            {isOpen && typeof document !== "undefined" && createPortal(DropdownMenu, document.body)}
        </>
    )
}

// ----------------------------------------------------------------------
// ASOSIY RENDER
// ----------------------------------------------------------------------
export default function QuestionRenderer({
    question,
    answer = "",
    onAnswer,
    onInputChange,
    fontSize = 16,
}: QuestionRendererProps) {
    if (!question) return null

    const commonProps = { question, answer, onAnswer, onInputChange, fontSize }

    switch (question.type) {
        case "TRUE_FALSE_NOT_GIVEN":
            return <TrueFalseNotGivenRenderer {...commonProps} />

        case "MULTIPLE_CHOICE":
            return <MultipleChoiceRenderer {...commonProps} />

        case "GAP_FILL_FILL":
            return <GapFillFillRenderer {...commonProps} />

        case "TEXT_MATCH":
            return <SelectRenderer {...commonProps} placeholder="Paragrafni tanlang..." />

        case "HEADINGS_MATCH":
            return <SelectRenderer {...commonProps} placeholder="Sarlavhani tanlang..." />

        case "GAP_FILL":
            return null

        default:
            return (
                <div className="rounded-lg border border-red-200 bg-red-50 p-2 text-[11px] font-medium text-red-600">
                    Qo&apos;llab-quvvatlanmaydi: {question.type}
                </div>
            )
    }
}