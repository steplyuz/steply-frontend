'use client'

import { useCallback, useEffect, useState } from 'react'
import { Globe2, Loader2, MonitorSmartphone, Save, ShieldCheck, Trash2 } from 'lucide-react'
import { useAuth } from '@/lib/auth/auth-context'
import { profileApi } from '@/lib/api'
import { getErrorMessage } from '@/lib/api/client'
import type { Session } from '@/lib/api/types'
import { Empty, ErrorBox, Field, PageHeader, Section, btn, fmtDate, input } from '@/components/dashboard/ui'

export default function SettingsPage() {
  const { user, refresh } = useAuth()
  const [language, setLanguage] = useState('uz')
  const [timezone, setTimezone] = useState('Asia/Tashkent')
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null)
  const [sessions, setSessions] = useState<Session[] | null>(null)
  const [sessionsError, setSessionsError] = useState('')
  const [revoking, setRevoking] = useState<string | null>(null)

  useEffect(() => {
    setLanguage(user?.profile?.language || 'uz')
    setTimezone(user?.profile?.timezone || 'Asia/Tashkent')
  }, [user?.profile?.language, user?.profile?.timezone])

  const loadSessions = useCallback(async () => {
    setSessionsError('')
    try {
      setSessions(await profileApi.sessions())
    } catch (e) {
      setSessionsError(getErrorMessage(e))
    }
  }, [])

  useEffect(() => { void loadSessions() }, [loadSessions])

  async function savePreferences(e: React.FormEvent) {
    e.preventDefault()
    setSaving(true)
    setMessage(null)
    try {
      await profileApi.update({ language, timezone })
      await refresh()
      setMessage({ ok: true, text: 'Sozlamalar saqlandi.' })
    } catch (e) {
      setMessage({ ok: false, text: getErrorMessage(e) })
    } finally {
      setSaving(false)
    }
  }

  async function revokeSession(sessionId: string) {
    if (!window.confirm('Ushbu qurilmadagi seansni tugatmoqchimisiz?')) return
    setRevoking(sessionId)
    setSessionsError('')
    try {
      await profileApi.revokeSession(sessionId)
      await loadSessions()
    } catch (e) {
      setSessionsError(getErrorMessage(e))
    } finally {
      setRevoking(null)
    }
  }

  const activeSessions = (sessions ?? []).filter((session) => !session.is_revoked)

  return (
    <div className="space-y-8 sm:space-y-10">
      <PageHeader title="Sozlamalar" desc="Til, vaqt zonasi va hisobingiz xavfsizligini boshqaring." />

      <Section title="Ilova sozlamalari" description="Bu sozlamalar profil ma’lumotlaridan alohida saqlanadi.">
        <form onSubmit={savePreferences} className="surface space-y-5 p-5 sm:p-6">
          <div className="flex items-start gap-3">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-[#E4F70A]/35 text-foreground">
              <Globe2 className="size-5" />
            </span>
            <div>
              <h3 className="font-semibold text-foreground">Til va vaqt</h3>
              <p className="mt-1 text-sm text-muted-foreground">Interfeys tilini va sanalar ko‘rsatiladigan vaqt zonasini tanlang.</p>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Interfeys tili">
              <select className={input} value={language} onChange={(e) => setLanguage(e.target.value)}>
                <option value="uz">O‘zbekcha</option>
                <option value="ru">Русский</option>
                <option value="en">English</option>
              </select>
            </Field>
            <Field label="Vaqt zonasi">
              <select className={input} value={timezone} onChange={(e) => setTimezone(e.target.value)}>
                <option value="Asia/Tashkent">Toshkent (UTC+5)</option>
                <option value="Europe/Istanbul">Istanbul</option>
                <option value="Europe/London">London</option>
                <option value="Europe/Berlin">Berlin</option>
                <option value="America/New_York">New York</option>
                <option value="UTC">UTC</option>
              </select>
            </Field>
          </div>

          {message && (
            <p role="status" className={`rounded-lg border px-3 py-2 text-sm ${message.ok ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700' : 'border-red-500/30 bg-red-500/10 text-red-700'}`}>
              {message.text}
            </p>
          )}
          <button type="submit" disabled={saving} className={btn.primary}>
            {saving ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
            {saving ? 'Saqlanmoqda…' : 'Sozlamalarni saqlash'}
          </button>
        </form>
      </Section>

      <Section title="Faol seanslar" description="Hisobingiz qaysi qurilmalarda ochiq ekanini tekshiring. Notanish seansni shu yerdan tugatishingiz mumkin.">
        {sessionsError && <div className="mb-3"><ErrorBox message={sessionsError} onRetry={loadSessions} /></div>}
        {sessions === null && !sessionsError ? (
          <div className="h-24 animate-pulse rounded-xl bg-muted" aria-busy="true" />
        ) : activeSessions.length === 0 ? (
          <Empty text="Faol seans topilmadi." />
        ) : (
          <div className="space-y-3">
            {activeSessions.map((session) => (
              <div key={session.id} className="surface flex flex-wrap items-center gap-3 p-4 sm:p-5">
                <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-background text-foreground">
                  <MonitorSmartphone className="size-5" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{session.user_agent || 'Noma’lum qurilma'}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{session.ip_address || 'IP noma’lum'} · oxirgi faollik {fmtDate(session.last_active)}</p>
                  <p className="mt-1 inline-flex items-center gap-1 text-xs text-emerald-700"><ShieldCheck className="size-3.5" /> Faol seans</p>
                </div>
                <button
                  type="button"
                  onClick={() => void revokeSession(session.id)}
                  disabled={revoking === session.id}
                  className={btn.danger}
                >
                  {revoking === session.id ? <Loader2 className="size-4 animate-spin" /> : <Trash2 className="size-4" />}
                  Seansni tugatish
                </button>
              </div>
            ))}
          </div>
        )}
      </Section>
    </div>
  )
}
