'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { AlertCircle, BookOpenText, ChartNoAxesCombined, CirclePlay, Headphones, Loader2, Mic, PenLine, RefreshCw, Video, X } from 'lucide-react'
import { useApi } from '@/lib/api/use-api'
import { apiUrl } from '@/lib/api/config'
import { refreshSession } from '@/lib/api/client'
import { Badge, Empty, ErrorBox, Loading, Meter, btn } from '@/components/dashboard/ui'

type Skill = 'READING' | 'LISTENING' | 'WRITING' | 'SPEAKING'
type AnalysisVideo = { id: number | string; skill: Skill; test_id: string; title: string; created_at: string }
type SkillResult = { id: number | string; exam_id: string; raw_score?: number; correct_answers?: number; total_questions?: number; standard_score?: number; cefr_level?: string | null; percentage?: number; created_at: string }
type QuestionReview = { question_number: number; question_text?: string | null; part_title?: string | null; user_answer?: string[] | string | null; correct_answer?: string[] | string | null; is_correct: boolean; type?: string }
type ResultDetail = { summary: SkillResult; review: QuestionReview[] }
type Quota = { tier: string; weekly_limit: number | null; weekly_used: number; weekly_remaining: number | null; monthly_limit: number | null; monthly_used: number; monthly_remaining: number | null }

const SKILLS: Record<Skill, { label: string; icon: typeof Video }> = {
  READING: { label: 'Reading', icon: BookOpenText },
  LISTENING: { label: 'Listening', icon: Headphones },
  WRITING: { label: 'Writing', icon: PenLine },
  SPEAKING: { label: 'Speaking', icon: Mic },
}

export default function AnalysisPage() {
  const videos = useApi<AnalysisVideo[]>('/analysis/videos')
  const limits = useApi<Quota>('/analysis/quota')
  const readingResults = useApi<SkillResult[]>('/reading-tests/me/results')
  const listeningResults = useApi<SkillResult[]>('/listening-tests/me/results')
  const [filter, setFilter] = useState<Skill | 'ALL'>('ALL')
  const [selected, setSelected] = useState<AnalysisVideo | null>(null)
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const [loadingVideo, setLoadingVideo] = useState(false)
  const [videoError, setVideoError] = useState('')
  const [openedResult, setOpenedResult] = useState<{ skill: 'READING' | 'LISTENING'; id: string | number } | null>(null)
  const [resultDetail, setResultDetail] = useState<ResultDetail | null>(null)
  const [resultLoading, setResultLoading] = useState(false)
  const [resultError, setResultError] = useState('')
  const player = useRef<HTMLElement | null>(null)

  useEffect(() => () => { if (videoUrl) URL.revokeObjectURL(videoUrl) }, [videoUrl])

  async function openVideo(item: AnalysisVideo) {
    setSelected(item)
    setLoadingVideo(true)
    setVideoError('')
    if (videoUrl) URL.revokeObjectURL(videoUrl)
    setVideoUrl(null)
    requestAnimationFrame(() => player.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }))
    const url = apiUrl(`/analysis/${encodeURIComponent(item.skill)}/${encodeURIComponent(item.test_id)}`)
    try {
      let response = await fetch(url, { credentials: 'include' })
      if (response.status === 401 && await refreshSession()) response = await fetch(url, { credentials: 'include' })
      if (!response.ok) {
        let message = response.statusText || 'Videoni yuklab bo‘lmadi'
        try { const data = await response.json(); message = data?.detail || data?.error?.message || message } catch {}
        throw new Error(message)
      }
      setVideoUrl(URL.createObjectURL(await response.blob()))
      limits.reload()
    } catch (error) {
      setVideoError(error instanceof Error ? error.message : 'Videoni yuklab bo‘lmadi')
    } finally {
      setLoadingVideo(false)
    }
  }

  function closePlayer() {
    if (videoUrl) URL.revokeObjectURL(videoUrl)
    setVideoUrl(null); setSelected(null); setVideoError('')
  }

  async function openResult(skill: 'READING' | 'LISTENING', id: string | number) {
    setOpenedResult({ skill, id }); setResultDetail(null); setResultError(''); setResultLoading(true)
    const path = skill === 'READING' ? `/reading-tests/me/results/${encodeURIComponent(String(id))}` : `/listening-tests/me/results/${encodeURIComponent(String(id))}`
    try {
      let response = await fetch(apiUrl(path), { credentials: 'include' })
      if (response.status === 401 && await refreshSession()) response = await fetch(apiUrl(path), { credentials: 'include' })
      if (!response.ok) {
        let message = response.statusText || 'Natija tahlilini yuklab bo‘lmadi'
        try { const data = await response.json(); message = data?.detail || data?.error?.message || message } catch {}
        throw new Error(message)
      }
      setResultDetail(await response.json())
    } catch (error) { setResultError(error instanceof Error ? error.message : 'Natija tahlilini yuklab bo‘lmadi') }
    finally { setResultLoading(false) }
  }
  const answerText = (value: string[] | string | null | undefined) => Array.isArray(value) ? (value.join(', ') || '—') : (value || '—')

  const counts = useMemo(() => {
    const c: Record<string, number> = { ALL: videos.data?.length ?? 0 }
    videos.data?.forEach((v) => { c[v.skill] = (c[v.skill] ?? 0) + 1 })
    return c
  }, [videos.data])
  const visible = (videos.data ?? []).filter((v) => filter === 'ALL' || v.skill === filter)
  const quota = limits.data

  return (
    <div className="space-y-8 sm:space-y-10">
      <section className="relative isolate overflow-hidden rounded-2xl border border-border bg-white p-5 shadow-[0_8px_28px_rgba(11,11,13,0.035)] sm:p-7 lg:p-8">
        <div aria-hidden="true" className="absolute -right-12 -top-16 -z-10 size-64 rounded-full bg-primary/25 blur-3xl" />
        <div className="max-w-2xl">
          <div className="mb-4 inline-flex size-12 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><ChartNoAxesCombined className="size-6" strokeWidth={2.1} /></div>
          <p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-muted-foreground">Steply · Tahlil</p>
          <h1 className="text-3xl font-bold tracking-[-0.04em] text-foreground sm:text-4xl">Analysis</h1>
          <p className="mt-3 text-sm leading-6 text-muted-foreground sm:text-base">Reading, Listening, Writing va Speaking testlari bo‘yicha tahlil videolari. Xatolaringizni tushunib, keyingi urinishda yaxshilang.</p>
        </div>
      </section>

      <section aria-labelledby="analysis-limits" className="space-y-4">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Foydalanish</p>
            <h2 id="analysis-limits" className="mt-1 text-xl font-bold tracking-tight sm:text-2xl">Limitlar</h2>
          </div>
          {quota && <Badge tone="primary">{quota.tier.toUpperCase()} tarif</Badge>}
        </div>
        {limits.loading ? <Loading rows={2} /> : limits.error ? <ErrorBox message={limits.error.message} onRetry={limits.reload} /> : quota ? (
          <div className="grid gap-3 md:grid-cols-2">
            <Meter label="Haftalik sarf" used={quota.weekly_used} limit={quota.weekly_limit} remaining={quota.weekly_remaining} unit="video" />
            <Meter label="Oylik sarf" used={quota.monthly_used} limit={quota.monthly_limit} remaining={quota.monthly_remaining} unit="video" />
          </div>
        ) : null}
      </section>

      {selected && (
        <section ref={player} aria-label={selected.title} className="overflow-hidden rounded-2xl border border-border bg-white shadow-[0_8px_28px_rgba(11,11,13,0.05)]">
          <div className="flex items-center justify-between gap-3 border-b border-border p-4 sm:px-6">
            <div className="min-w-0">
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">{SKILLS[selected.skill]?.label ?? selected.skill}</p>
              <h2 className="truncate text-lg font-bold tracking-tight">{selected.title}</h2>
            </div>
            <button type="button" onClick={closePlayer} aria-label="Yopish" className={`${btn.outline} !min-h-9 !px-2.5`}><X className="size-4" /></button>
          </div>
          <div className="bg-foreground">
            {loadingVideo ? (
              <div className="flex aspect-video items-center justify-center gap-2 text-sm text-white/70"><Loader2 className="size-4 animate-spin" /> Video yuklanmoqda…</div>
            ) : videoError ? (
              <div className="flex aspect-video flex-col items-center justify-center gap-3 p-6 text-center text-sm text-white">
                <AlertCircle className="size-6 text-primary" /><p className="max-w-md">{videoError}</p>
                <button type="button" onClick={() => openVideo(selected)} className={btn.primary}><RefreshCw className="size-4" /> Qayta urinish</button>
              </div>
            ) : videoUrl ? (
              <video key={videoUrl} className="mx-auto max-h-[70vh] w-full" controls playsInline autoPlay src={videoUrl}>Brauzeringiz video formatini qo‘llamaydi.</video>
            ) : null}
          </div>
        </section>
      )}

      <section aria-labelledby="reading-listening-analysis" className="space-y-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Imtihon natijalari</p>
          <h2 id="reading-listening-analysis" className="mt-1 text-xl font-bold tracking-tight sm:text-2xl">Reading va Listening tahlili</h2>
          <p className="mt-2 text-sm text-muted-foreground">Har bir urinishning natija ID’si, test ID’si va savollar bo‘yicha javob tahlili.</p>
        </div>
        <div className="grid gap-4 xl:grid-cols-2">
          {([['READING', 'Reading', readingResults], ['LISTENING', 'Listening', listeningResults]] as const).map(([skill, label, resource]) => {
            const results = resource.data ?? []
            return <section key={skill} aria-label={`${label} natijalari`} className="rounded-2xl border border-border bg-white p-4 shadow-[0_4px_16px_rgba(11,11,13,0.02)] sm:p-5">
              <div className="mb-4 flex items-center justify-between gap-3"><div className="flex items-center gap-2">{skill === 'READING' ? <BookOpenText className="size-5" /> : <Headphones className="size-5" />}<h3 className="text-lg font-bold">{label}</h3></div><Badge>{results.length} ta natija</Badge></div>
              {resource.loading ? <Loading rows={2} /> : resource.error ? <ErrorBox message={resource.error.message} onRetry={resource.reload} /> : results.length === 0 ? <Empty text={`${label} bo‘yicha topshirilgan test natijalari hozircha yo‘q.`} /> : <div className="space-y-2">
                {results.map((result) => <article key={`${skill}-${result.id}`} className="rounded-xl border border-border p-3 sm:p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3"><div className="min-w-0 space-y-1"><p className="text-sm font-bold">Test ID: <span className="break-all font-mono font-medium">{result.exam_id}</span></p><p className="text-xs text-muted-foreground">Natija ID: <span className="break-all font-mono">{result.id}</span></p><p className="text-xs text-muted-foreground">{result.created_at ? new Date(result.created_at).toLocaleString() : 'Sana ko‘rsatilmagan'}</p></div><div className="text-right"><p className="text-lg font-bold tabular-nums">{Number(result.standard_score ?? result.raw_score ?? result.correct_answers ?? 0).toFixed(1)}</p><p className="text-xs text-muted-foreground">{result.cefr_level || 'Daraja yo‘q'} · {Math.round(result.percentage ?? 0)}%</p></div></div>
                  <button type="button" onClick={() => openResult(skill, result.id)} className={`${btn.outline} mt-3 w-full`}>Savollar tahlili va ID’larni ko‘rish</button>
                </article>)}
              </div>}
            </section>
          })}
        </div>
      </section>

      {openedResult && <section aria-label="Savollar bo‘yicha tahlil" className="rounded-2xl border border-border bg-white p-4 shadow-[0_8px_28px_rgba(11,11,13,0.04)] sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-3 border-b border-border pb-4"><div><p className="text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">{SKILLS[openedResult.skill].label} · batafsil tahlil</p><h2 className="mt-1 text-xl font-bold">Natija ID: <span className="break-all font-mono">{openedResult.id}</span></h2><p className="mt-1 break-all text-xs text-muted-foreground">Test ID: {resultDetail?.summary.exam_id ?? 'Yuklanmoqda…'}</p></div><button type="button" onClick={() => { setOpenedResult(null); setResultDetail(null); setResultError('') }} className={btn.outline}><X className="size-4" /> Yopish</button></div>
        {resultLoading ? <div className="py-6"><Loading rows={3} /></div> : resultError ? <div className="pt-4"><ErrorBox message={resultError} onRetry={() => openResult(openedResult.skill, openedResult.id)} /></div> : resultDetail ? <div className="space-y-4 pt-4"><div className="grid gap-3 sm:grid-cols-3"><div className="rounded-xl bg-background p-3"><p className="text-xs text-muted-foreground">Ball</p><p className="text-xl font-bold">{resultDetail.summary.standard_score ?? resultDetail.summary.raw_score ?? '—'}</p></div><div className="rounded-xl bg-background p-3"><p className="text-xs text-muted-foreground">Foiz</p><p className="text-xl font-bold">{Math.round(resultDetail.summary.percentage ?? 0)}%</p></div><div className="rounded-xl bg-background p-3"><p className="text-xs text-muted-foreground">CEFR</p><p className="text-xl font-bold">{resultDetail.summary.cefr_level || '—'}</p></div></div>
          <div className="space-y-3">{(resultDetail.review ?? []).map((q) => <article key={`${openedResult.skill}-${q.question_number}`} className="rounded-xl border border-border p-4"><div className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-bold">Savol {q.question_number}</h3><Badge tone={q.is_correct ? 'green' : 'red'}>{q.is_correct ? 'To‘g‘ri' : 'Noto‘g‘ri'}</Badge></div>{q.part_title && <p className="mt-1 text-xs text-muted-foreground">{q.part_title}</p>}{q.question_text && <p className="mt-2 text-sm">{q.question_text}</p>}<div className="mt-3 grid gap-2 sm:grid-cols-2"><p className="rounded-lg bg-background p-3 text-sm"><span className="block text-xs text-muted-foreground">Sizning javobingiz</span><span className="mt-1 block font-medium">{answerText(q.user_answer)}</span></p><p className="rounded-lg bg-background p-3 text-sm"><span className="block text-xs text-muted-foreground">To‘g‘ri javob</span><span className="mt-1 block font-medium">{answerText(q.correct_answer)}</span></p></div></article>)}</div>
        </div> : null}
      </section>}

      <section aria-labelledby="analysis-videos" className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Kutubxona</p>
            <h2 id="analysis-videos" className="mt-1 text-xl font-bold tracking-tight sm:text-2xl">Tahlil videolari</h2>
          </div>
          <div role="tablist" aria-label="Ko‘nikma bo‘yicha filtr" className="flex flex-wrap gap-1.5">
            {(['ALL', ...Object.keys(SKILLS)] as (Skill | 'ALL')[]).map((k) => {
              const on = filter === k
              return (
                <button key={k} role="tab" aria-selected={on} type="button" onClick={() => setFilter(k)}
                  className={`inline-flex min-h-9 items-center gap-1.5 rounded-full border px-3.5 text-xs font-semibold transition ${on ? 'border-foreground bg-foreground text-background' : 'border-border bg-white text-muted-foreground hover:border-border-strong hover:text-foreground'}`}>
                  {k === 'ALL' ? 'Hammasi' : SKILLS[k].label}
                  <span className={`tabular-nums ${on ? 'text-primary' : 'text-muted-foreground/70'}`}>{counts[k] ?? 0}</span>
                </button>
              )
            })}
          </div>
        </div>

        {videos.loading ? <Loading rows={3} /> : videos.error ? <ErrorBox message={videos.error.message} onRetry={videos.reload} /> : !visible.length ? (
          <Empty text={filter === 'ALL' ? 'Hozircha tahlil videosi joylanmagan. Administrator video qo‘shganidan keyin shu yerda ko‘rinadi.' : 'Bu ko‘nikma bo‘yicha video yo‘q.'} />
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {visible.map((item) => {
              const Icon = SKILLS[item.skill]?.icon ?? Video
              const active = selected?.id === item.id
              return (
                <article key={item.id} className={`group flex min-h-48 flex-col justify-between rounded-2xl border bg-white p-5 shadow-[0_4px_16px_rgba(11,11,13,0.02)] transition duration-200 hover:-translate-y-0.5 hover:shadow-[0_12px_28px_rgba(11,11,13,0.06)] sm:p-6 ${active ? 'border-foreground' : 'border-border hover:border-foreground/20'}`}>
                  <div>
                    <div className="flex size-10 items-center justify-center rounded-xl bg-background text-foreground transition-colors group-hover:bg-primary"><Icon className="size-5" /></div>
                    <h3 className="mt-4 line-clamp-2 text-base font-bold leading-6">{item.title}</h3>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <span className="rounded-lg bg-background px-2.5 py-1.5 text-xs font-medium text-muted-foreground">{SKILLS[item.skill]?.label ?? item.skill}</span>
                      <span className="rounded-lg bg-background px-2.5 py-1.5 text-xs font-medium text-muted-foreground">Test {item.test_id}</span>
                    </div>
                  </div>
                  <div className="mt-6 border-t border-border pt-4">
                    <button type="button" onClick={() => openVideo(item)} disabled={loadingVideo} className={`${btn.primary} w-full`}>
                      {loadingVideo && active ? <Loader2 className="size-4 animate-spin" /> : <CirclePlay className="size-4" />} Tahlilni ko‘rish
                    </button>
                  </div>
                </article>
              )
            })}
          </div>
        )}
      </section>
    </div>
  )
}
