'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { CheckCircle2, Clock3, CreditCard, FileText, GraduationCap, RefreshCw, UploadCloud } from 'lucide-react'
import { mockExamsApi } from '@/lib/api/modules/mock-exams'
import { billingApi } from '@/lib/api/modules/billing'
import { getErrorMessage } from '@/lib/api/client'
import type { BillingOrder, PaymentDetails, MockExam } from '@/lib/api/types'
import { PageHeader, btn } from '@/components/dashboard/ui'

const STATUS_LABEL: Record<string, string> = {
  pending_payment: 'To‘lov kutilmoqda',
  under_review: 'Chek tekshirilmoqda',
  paid: 'To‘lov tasdiqlangan',
  rejected: 'Chek rad etilgan',
  cancelled: 'Bekor qilingan',
}

function money(value: number) {
  return `${value.toLocaleString('uz-UZ')} UZS`
}

export default function MockExamsPage() {
  const [exams, setExams] = useState<MockExam[]>([])
  const [orders, setOrders] = useState<BillingOrder[]>([])
  const [payment, setPayment] = useState<PaymentDetails | null>(null)
  const [files, setFiles] = useState<Record<string, File | undefined>>({})
  const [loading, setLoading] = useState(true)
  const [busyId, setBusyId] = useState<string | null>(null)
  const [uploadingId, setUploadingId] = useState<string | null>(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const reload = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const [examRows, orderRows, paymentDetails] = await Promise.all([
        mockExamsApi.getAll(),
        billingApi.myOrders(0, 100),
        billingApi.paymentDetails(),
      ])
      setExams(examRows)
      setOrders(orderRows)
      setPayment(paymentDetails)
    } catch (e) {
      setError(getErrorMessage(e, 'Mock Exam ma’lumotlarini yuklab bo‘lmadi.'))
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { void reload() }, [reload])

  const ordersByExam = useMemo(() => {
    const map = new Map<string, BillingOrder[]>()
    for (const order of orders) {
      if (order.product_type !== 'mock_exam' || !order.product_id) continue
      const list = map.get(order.product_id) ?? []
      list.push(order)
      map.set(order.product_id, list)
    }
    for (const list of map.values()) list.sort((a, b) => +new Date(b.created_at) - +new Date(a.created_at))
    return map
  }, [orders])

  async function buyExam(exam: MockExam) {
    setBusyId(exam.id)
    setError('')
    setNotice('')
    try {
      if (exam.is_purchased) {
        setNotice('Bu Mock Exam akkauntingizda allaqachon faollashtirilgan.')
      } else if (exam.price <= 0) {
        await mockExamsApi.buy(exam.id)
        setNotice('Bepul Mock Exam faollashtirildi.')
      } else {
        const current = ordersByExam.get(exam.id)?.find(order => ['pending_payment', 'under_review', 'rejected'].includes(order.status))
        if (current) {
          setNotice(current.status === 'under_review' ? 'To‘lov chekingiz tekshiruvda.' : 'Sizda ushbu imtihon uchun buyurtma mavjud. To‘lov bo‘limidan chek yuboring.')
        } else {
          const order = await billingApi.createOrder({ product_type: 'mock_exam', product_id: exam.id })
          setNotice(`Buyurtma yaratildi (${order.id.slice(0, 8)}). Quyidagi buyurtma orqali to‘lov chekini yuboring.`)
        }
      }
      await reload()
    } catch (e) {
      setError(getErrorMessage(e, 'Mock Exam xaridini yaratib bo‘lmadi.'))
    } finally {
      setBusyId(null)
    }
  }

  async function uploadReceipt(orderId: string) {
    const file = files[orderId]
    if (!file) {
      setError('Avval to‘lov chekini tanlang.')
      return
    }
    setUploadingId(orderId)
    setError('')
    setNotice('')
    try {
      await billingApi.uploadReceipt(orderId, file)
      setFiles(previous => ({ ...previous, [orderId]: undefined }))
      setNotice('Chek yuborildi. Admin tekshiruvidan keyin xarid huquqi faollashadi.')
      await reload()
    } catch (e) {
      setError(getErrorMessage(e, 'Chekni yuborib bo‘lmadi.'))
    } finally {
      setUploadingId(null)
    }
  }

  const hasPaymentDetails = Boolean(payment?.card_number || payment?.bank_name || payment?.account_number || payment?.phone_number)

  return (
    <div className="space-y-8 sm:space-y-10">
      <PageHeader
        title="Mock Exam"
        desc="To‘liq imtihonni tanlang. Pullik imtihonlarda buyurtma yaratiladi, chek yuboriladi va admin tasdiqlagandan keyin kirish huquqi faollashadi."
        action={<button type="button" onClick={() => void reload()} disabled={loading} className={btn.outline}><RefreshCw className={`size-4 ${loading ? 'animate-spin' : ''}`} /> Yangilash</button>}
      />

      {error && <div role="alert" className="rounded-xl border border-red-300 bg-red-50 p-4 text-sm text-red-800">{error}</div>}
      {notice && <div role="status" className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-sm text-emerald-800">{notice}</div>}

      {loading && exams.length === 0 ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{[0, 1, 2].map(x => <div key={x} className="h-52 animate-pulse rounded-2xl bg-white ring-1 ring-border" />)}</div>
      ) : exams.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-border bg-white p-8 text-center">
          <GraduationCap className="mx-auto size-8 text-muted-foreground" />
          <p className="mt-3 font-semibold">Hozircha faol Mock Exam yo‘q</p>
          <p className="mt-1 text-sm text-muted-foreground">Admin imtihon katalogiga yangi imtihon qo‘shgandan keyin shu yerda ko‘rinadi.</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {exams.map(exam => {
            const latestOrder = ordersByExam.get(exam.id)?.[0]
            const pending = latestOrder && ['pending_payment', 'rejected'].includes(latestOrder.status)
            return (
              <article key={exam.id} className="flex flex-col rounded-2xl border border-border bg-white p-5 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <span className="flex size-11 items-center justify-center rounded-xl bg-background text-foreground"><GraduationCap className="size-5" /></span>
                  {exam.is_purchased ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700"><CheckCircle2 className="size-3.5" /> Xarid qilingan</span>
                  ) : latestOrder?.status === 'under_review' ? (
                    <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-800"><Clock3 className="size-3.5" /> Tekshiruvda</span>
                  ) : null}
                </div>
                <h2 className="mt-4 text-lg font-bold text-foreground">{exam.title}</h2>
                {exam.description && <p className="mt-2 line-clamp-3 text-sm leading-5 text-muted-foreground">{exam.description}</p>}
                <div className="mt-4 flex flex-wrap gap-2 text-xs text-muted-foreground">
                  <span className="rounded-md bg-background px-2 py-1">{exam.cefr_level}</span>
                  {exam.duration_minutes ? <span className="rounded-md bg-background px-2 py-1">{exam.duration_minutes} daqiqa</span> : null}
                </div>
                <p className="mt-5 text-xl font-extrabold text-foreground">{exam.price > 0 ? money(exam.price) : 'Bepul'}</p>
                <button type="button" disabled={!!busyId || !!exam.is_purchased || latestOrder?.status === 'under_review'} onClick={() => void buyExam(exam)} className={`mt-4 ${btn.primary} w-full`}>
                  {busyId === exam.id ? 'Tayyorlanmoqda…' : exam.is_purchased ? 'Faollashtirilgan' : latestOrder?.status === 'under_review' ? 'Chek tekshiruvda' : pending ? 'Buyurtmani ko‘rish' : <><CreditCard className="size-4" /> {exam.price > 0 ? 'Xarid qilish' : 'Bepul olish'}</>}
                </button>
              </article>
            )
          })}
        </div>
      )}

      <section className="rounded-2xl border border-border bg-white p-5 sm:p-6">
        <div className="flex items-start gap-3">
          <CreditCard className="mt-0.5 size-5 shrink-0 text-muted-foreground" />
          <div className="min-w-0 flex-1">
            <h2 className="font-bold text-foreground">To‘lov rekvizitlari</h2>
            {!hasPaymentDetails ? (
              <p className="mt-2 text-sm text-muted-foreground">{payment?.instructions || 'To‘lov rekvizitlari hali sozlanmagan. Admin bilan bog‘laning.'}</p>
            ) : (
              <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {payment?.bank_name && <div className="rounded-xl bg-background p-3"><p className="text-xs text-muted-foreground">Bank</p><p className="mt-1 font-semibold">{payment.bank_name}</p></div>}
                {payment?.card_number && <div className="rounded-xl bg-background p-3"><p className="text-xs text-muted-foreground">Karta raqami</p><p className="mt-1 font-semibold">{payment.card_number}</p>{payment.card_holder && <p className="mt-1 text-xs text-muted-foreground">{payment.card_holder}</p>}</div>}
                {payment?.account_number && <div className="rounded-xl bg-background p-3"><p className="text-xs text-muted-foreground">Hisob raqam</p><p className="mt-1 font-semibold">{payment.account_number}</p></div>}
                {payment?.phone_number && <div className="rounded-xl bg-background p-3"><p className="text-xs text-muted-foreground">Telefon</p><p className="mt-1 font-semibold">{payment.phone_number}</p></div>}
              </div>
            )}
            {payment?.instructions && hasPaymentDetails && <p className="mt-3 text-sm leading-5 text-muted-foreground">{payment.instructions}</p>}
          </div>
        </div>
      </section>

      <section className="space-y-3">
        <div>
          <h2 className="text-lg font-bold text-foreground">Mock Exam buyurtmalari</h2>
          <p className="mt-1 text-sm text-muted-foreground">Chek yuborilgandan keyin admin tekshiradi. Tasdiqlanmaguncha pullik imtihonga kirish ochilmaydi.</p>
        </div>
        {orders.filter(order => order.product_type === 'mock_exam').length === 0 ? (
          <p className="rounded-xl border border-dashed border-border p-4 text-sm text-muted-foreground">Mock Exam uchun buyurtma yo‘q.</p>
        ) : orders.filter(order => order.product_type === 'mock_exam').map(order => {
          const canUpload = ['pending_payment', 'rejected'].includes(order.status)
          return (
            <article key={order.id} className="rounded-2xl border border-border bg-white p-4 sm:p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="font-semibold">{order.product_title}</p>
                  <p className="mt-1 text-xs text-muted-foreground">Buyurtma #{order.id.slice(0, 8)} · {money(order.amount)}</p>
                </div>
                <span className="rounded-full bg-background px-3 py-1 text-xs font-semibold">{STATUS_LABEL[order.status] ?? order.status}</span>
              </div>
              {canUpload && (
                <div className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end">
                  <label className="flex-1 text-xs font-semibold">
                    <span className="mb-1.5 block">To‘lov cheki (JPG, PNG, WEBP yoki PDF; 8 MB gacha)</span>
                    <input type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={e => setFiles(previous => ({ ...previous, [order.id]: e.target.files?.[0] }))} className="block w-full rounded-xl border border-border bg-white px-3 py-2 text-sm font-normal" />
                  </label>
                  <button type="button" disabled={!files[order.id] || uploadingId === order.id} onClick={() => void uploadReceipt(order.id)} className={`${btn.primary}`}>
                    <UploadCloud className="size-4" /> {uploadingId === order.id ? 'Yuborilmoqda…' : 'Chekni yuborish'}
                  </button>
                </div>
              )}
              {order.status === 'paid' && <p className="mt-3 inline-flex items-center gap-2 text-sm font-medium text-emerald-700"><CheckCircle2 className="size-4" /> Xarid tasdiqlangan; imtihon huquqi yangilanadi.</p>}
              {order.status === 'rejected' && order.admin_note && <p className="mt-3 text-sm text-red-700">Admin izohi: {order.admin_note}</p>}
              {order.status === 'pending_payment' && <p className="mt-3 inline-flex items-center gap-2 text-xs text-muted-foreground"><FileText className="size-3.5" /> To‘lovni amalga oshirib, chek faylini yuboring.</p>}
            </article>
          )
        })}
      </section>
    </div>
  )
}
