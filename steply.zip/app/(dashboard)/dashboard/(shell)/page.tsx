'use client'

import Link from 'next/link'
import { BookOpen, Headphones, Mic, Pencil, Sparkles, ArrowRight, CreditCard, RefreshCw } from 'lucide-react'
import { useAuth } from '@/lib/auth/auth-context'
import { useApi } from '@/lib/api/use-api'
import type { BillingLimits } from '@/lib/api/types'
import { Meter } from '@/components/dashboard/ui'

const PRACTICE_SKILLS = [
  { href: '/dashboard/reading', label: 'Reading', description: 'Matnlarni o‘qish va savollarni yechish', icon: BookOpen, tone: 'bg-secondary text-foreground' },
  { href: '/dashboard/listening', label: 'Listening', description: 'Audio tinglash va tushunishni mashq qilish', icon: Headphones, tone: 'bg-secondary text-foreground' },
  { href: '/dashboard/writing', label: 'Writing', description: 'Yozma topshiriqlar ustida ishlash', icon: Pencil, tone: 'bg-secondary text-foreground' },
  { href: '/dashboard/speaking', label: 'Speaking', description: 'Gapirish va talaffuzni mashq qilish', icon: Mic, tone: 'bg-secondary text-foreground' },
]

function num(value: unknown): number | null {
  return typeof value === 'number' && Number.isFinite(value) ? value : null
}

export default function DashboardPage() {
  const { user } = useAuth()
  const limits = useApi<BillingLimits>('/billing/me/limits')
  const name = user?.profile?.full_name || ''
  const firstName = name.replace(/[^\p{L}\p{N}\s'‘’-]/gu, '').trim().split(/\s+/)[0]

  return (
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-3xl bg-foreground p-6 text-white sm:p-9">
        <div aria-hidden="true" className="pointer-events-none absolute -right-12 -top-16 size-64 rounded-full bg-[#E4F70A]/15 blur-3xl" />
        <div className="relative max-w-2xl">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold"><Sparkles className="size-3.5 text-[#E4F70A]" /> Steply Practice</span>
          <h1 className="mt-4 text-3xl font-extrabold tracking-tight sm:text-4xl">{firstName ? `Salom, ${firstName}!` : 'Xush kelibsiz!'}</h1>
          <p className="mt-3 max-w-xl text-sm leading-6 text-white/70 sm:text-base">Bugun qaysi ko‘nikmani rivojlantiramiz? Mashqni tanlang va o‘z sur’atingizda davom eting.</p>
          <Link href="/dashboard/reading" className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-xl bg-[#E4F70A] px-5 py-3 text-sm font-bold text-foreground transition hover:bg-[#d4e509]">Mashqni boshlash <ArrowRight className="size-4" /></Link>
        </div>
      </section>

      <section aria-labelledby="practice-skills">
        <div className="mb-4">
          <h2 id="practice-skills" className="text-xl font-bold tracking-tight text-foreground">Practice bo‘limlari</h2>
          <p className="mt-1 text-sm text-muted-foreground">To‘rtta asosiy ko‘nikma bo‘yicha mashq qiling.</p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {PRACTICE_SKILLS.map(({ href, label, description, icon: Icon, tone }) => (
            <Link key={href} href={href} className="group rounded-2xl border border-border bg-white p-5 transition hover:-translate-y-0.5 hover:border-foreground/30 hover:shadow-lg">
              <span className={`flex size-12 items-center justify-center rounded-xl ${tone}`}><Icon className="size-5" /></span>
              <h3 className="mt-4 text-lg font-bold text-foreground">{label}</h3>
              <p className="mt-2 min-h-10 text-sm leading-5 text-muted-foreground">{description}</p>
              <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-foreground">Bo‘limga o‘tish <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" /></span>
            </Link>
          ))}
        </div>
      </section>

      <section aria-labelledby="weekly-usage-heading" className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 id="weekly-usage-heading" className="text-xl font-bold tracking-tight text-foreground">Haftalik limit sarfi</h2>
            <p className="mt-1 text-sm text-muted-foreground">Practice testlaridagi foydalanishingiz backend ma’lumotlari asosida ko‘rsatiladi.</p>
          </div>
          <button type="button" onClick={limits.reload} disabled={limits.loading} className="inline-flex min-h-9 items-center gap-2 rounded-xl border border-border bg-white px-3 py-2 text-xs font-semibold transition hover:bg-muted disabled:opacity-60">
            <RefreshCw className={`size-3.5 ${limits.loading ? 'animate-spin' : ''}`} /> Yangilash
          </button>
        </div>

        {limits.loading && !limits.data ? (
          <div className="h-36 animate-pulse rounded-2xl bg-white ring-1 ring-border" />
        ) : limits.error ? (
          <div className="rounded-2xl border border-dashed border-border bg-white p-5">
            <p className="text-sm font-semibold">Limitlarni yuklab bo‘lmadi.</p>
            <p className="mt-1 text-sm text-muted-foreground">{limits.error.message}</p>
            <button type="button" onClick={limits.reload} className="mt-3 text-sm font-semibold underline underline-offset-4">Qayta urinish</button>
          </div>
        ) : limits.data?.practice ? (
          <div className="grid gap-3 md:grid-cols-2">
            {([
              { label: 'Haftalik umumiy limit', used: limits.data.practice.used_this_week, limit: limits.data.practice.weekly_limit, remaining: limits.data.practice.remaining, unit: 'hafta' },
              { label: 'Oylik umumiy limit', used: limits.data.practice.used_this_month, limit: limits.data.practice.monthly_limit, remaining: limits.data.practice.remaining_this_month, unit: 'oy' },
            ] as const).map((quota) => {
              return <Meter key={quota.unit} label={quota.label} used={quota.used ?? 0} limit={quota.limit} remaining={quota.remaining} unit="mashq" />
            })}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-border bg-white p-5 text-sm text-muted-foreground">Practice limit ma’lumotlari topilmadi.</div>
        )}
      </section>

      <section className="flex flex-col gap-4 rounded-2xl border border-border bg-white p-5 sm:flex-row sm:items-center sm:justify-between sm:p-6">
        <div><h2 className="font-bold text-foreground">Tarif va limitlar</h2><p className="mt-1 text-sm text-muted-foreground">Obunangizni va mavjud mashq limitlarini tekshiring.</p></div>
        <Link href="/dashboard/billing" className="inline-flex min-h-10 items-center justify-center gap-2 rounded-xl border border-border px-4 py-2 text-sm font-semibold transition hover:bg-muted"><CreditCard className="size-4" /> Tariflarni ko‘rish</Link>
      </section>
    </div>
  )
}
