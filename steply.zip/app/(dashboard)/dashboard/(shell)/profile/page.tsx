'use client'

import { useState } from 'react'
import { useApi } from '@/lib/api/use-api'
import { useAuth } from '@/lib/auth/auth-context'
import { UserAvatar } from '@/components/layout/user-badges'
import { del, errMsg, patch, post, put, upload } from '@/lib/api/dashboard'
import { Badge, Empty, ErrorBox, Field, Loading, PageHeader, Section, btn, input } from '@/components/dashboard/ui'

type Profile = { full_name?: string | null; username?: string | null; avatar_url?: string | null; bio?: string | null; birth_date?: string | null; language?: string | null; timezone?: string | null }
type Contact = { id: number; contact_type: string; value: string; is_verified: boolean; is_primary: boolean }
type Me = { global_role: string; profile: Profile; contacts: Contact[] }

function ProfileForm({ me, onSaved }: { me: Me; onSaved: () => void }) {
  const p = me.profile
  const [f, setF] = useState({
    full_name: p.full_name ?? '', username: p.username ?? '', bio: p.bio ?? '',
    birth_date: p.birth_date ?? '', language: p.language ?? 'uz', timezone: p.timezone ?? 'Asia/Tashkent',
  })
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
    setF((s) => ({ ...s, [k]: e.target.value }))

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setBusy(true); setMsg(null)
    try {
      await put('/users/me/profile', { ...f, birth_date: f.birth_date || null, bio: f.bio || null })
      setMsg({ ok: true, text: 'Saqlandi.' }); onSaved()
    } catch (err) { setMsg({ ok: false, text: errMsg(err) }) } finally { setBusy(false) }
  }
  async function avatar(file: File) {
    setMsg(null)
    try { await upload('/users/me/avatar', file); setMsg({ ok: true, text: 'Rasm yangilandi.' }); onSaved() }
    catch (err) { setMsg({ ok: false, text: errMsg(err) }) }
  }

  return (
    <form onSubmit={submit} className="surface space-y-4 p-5">
      <div className="flex items-center gap-4">
        <UserAvatar name={p.full_name} src={p.avatar_url} className="size-16 text-xl" />
        <label className={`${btn.outline} cursor-pointer focus-within:ring-2 focus-within:ring-foreground`}>
          Rasmni almashtirish
          <input type="file" accept="image/*" className="sr-only" onChange={(e) => { const x = e.target.files?.[0]; e.target.value = ''; if (x) avatar(x) }} />
        </label>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="To‘liq ism"><input className={input} value={f.full_name} onChange={set('full_name')} /></Field>
        <Field label="Username"><input className={input} value={f.username} onChange={set('username')} /></Field>
        <Field label="Tug‘ilgan sana"><input type="date" className={input} value={f.birth_date} onChange={set('birth_date')} /></Field>
        <Field label="Til">
          <select className={input} value={f.language} onChange={set('language')}>
            <option value="uz">O‘zbekcha</option><option value="ru">Русский</option><option value="en">English</option>
          </select>
        </Field>
        <Field label="Vaqt zonasi"><input className={input} value={f.timezone} onChange={set('timezone')} /></Field>
      </div>
      <Field label="Bio"><textarea rows={3} className={input} value={f.bio} onChange={set('bio')} /></Field>
      <div className="flex items-center gap-3">
        <button className={btn.primary} disabled={busy}>{busy ? 'Saqlanmoqda…' : 'Saqlash'}</button>
        {msg && <span role="status" className={`text-sm ${msg.ok ? 'text-emerald-700 dark:text-emerald-400' : 'text-red-700 dark:text-red-400'}`}>{msg.text}</span>}
      </div>
    </form>
  )
}

export default function ProfilePage() {
  const { refresh: refreshAuth } = useAuth()
  const meApi = useApi<Me>('/users/me')
  // Saqlangandan so'ng sidebar va topbar (avatar, ism) ham yangilansin
  const me = { ...meApi, reload: () => { meApi.reload(); void refreshAuth() } }
  const [type, setType] = useState('email')
  const [value, setValue] = useState('')
  const [err, setErr] = useState('')

  async function act(fn: () => Promise<unknown>, after: () => void) {
    setErr('')
    try { await fn(); after() } catch (e) { setErr(errMsg(e)) }
  }

  return (
    <div className="space-y-8 sm:space-y-10">
      <PageHeader title="Profil" desc="Shaxsiy ma’lumotlaringiz, avatar va kontaktlaringizni boshqaring." />
      {err && <ErrorBox message={err} />}

      {me.loading ? <Loading rows={1} /> : me.error ? <ErrorBox message={me.error.message} onRetry={me.reload} /> : me.data && (
        <>
          <ProfileForm me={me.data} onSaved={me.reload} />

          <Section title="Kontaktlar">
            <div className="space-y-3">
              {me.data.contacts.length === 0 && <Empty text="Kontakt yo‘q." />}
              {me.data.contacts.map((c) => (
                <div key={c.id} className="surface flex flex-wrap items-center justify-between gap-3 p-4">
                  <div>
                    <p className="font-medium">{c.value}</p>
                    <p className="text-xs text-muted-foreground">{c.contact_type}</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {c.is_primary && <Badge tone="primary">Asosiy</Badge>}
                    {c.is_verified && <Badge tone="green">Tasdiqlangan</Badge>}
                    {!c.is_primary && <button className={btn.outline} onClick={() => act(() => patch(`/users/me/contacts/${c.id}/primary`), me.reload)}>Asosiy qilish</button>}
                    {!c.is_primary && <button className={btn.danger} onClick={() => act(() => del(`/users/me/contacts/${c.id}`), me.reload)}>O‘chirish</button>}
                  </div>
                </div>
              ))}
              <form
                className="surface flex flex-wrap gap-3 p-4"
                onSubmit={(e) => { e.preventDefault(); if (value.trim()) act(() => post('/users/me/contacts', { contact_type: type, value: value.trim() }), () => { setValue(''); me.reload() }) }}
              >
                <select className={`${input} w-28`} value={type} onChange={(e) => setType(e.target.value)} aria-label="Kontakt turi">
                  <option value="email">Email</option><option value="phone">Telefon</option>
                </select>
                <input className={`${input} min-w-0 flex-1`} value={value} onChange={(e) => setValue(e.target.value)} placeholder={type === 'email' ? 'name@example.com' : '998901234567'} aria-label="Kontakt qiymati" />
                <button className={btn.primary}>Qo‘shish</button>
              </form>
            </div>
          </Section>
        </>
      )}

    </div>
  )
}
