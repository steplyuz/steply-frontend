'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Ban, BookOpen, Check, CheckCheck, CheckCircle2, Clock, Copy, CreditCard, Headphones, Mic, Pencil, Phone, Search, Sparkles, Ticket, X } from 'lucide-react'
import { useApi } from '@/lib/api/use-api'
import type { BillingLimits, BillingProduct } from '@/lib/api/types'
import { post, upload, errMsg } from '@/lib/api/dashboard'
import { FOCUS, INK, LIME } from '@/lib/brand'
import {
  Badge, Empty, ErrorBox, Loading, PageHeader, Section, fmtDate, fmtMoney, input, type Tone as BadgeTone,
} from '@/components/dashboard/ui'

type PaymentRequisites = {
  card_number: string
  card_holder: string
  bank_name: string
  account_number?: string | null
  phone_number?: string | null
  instructions?: string | null
}

type Plan = { id: number; name: string; description?: string | null; price: number; duration_days: number; tier: string; ai_limit: number; exam_limit?: number; included_skills?: string[]; ai_enabled?: boolean; discount_percent?: number; is_active?: boolean }
type Order = { id: string; product_title?: string | null; product_type?: string; amount: number; discount_amount?: number; status: string; created_at: string }
type Sub = { end_date: string; is_active: boolean } | null

const orderTone = (s: string): BadgeTone =>
  /approv|paid/i.test(s) ? 'green' : /review/i.test(s) ? 'sky' : /reject|cancel/i.test(s) ? 'red' : /pending/i.test(s) ? 'amber' : 'muted'
const orderLabel = (s: string) =>
  /approv|paid/i.test(s) ? 'Tasdiqlangan'
    : /review/i.test(s) ? 'Tekshiruvda'
      : /reject/i.test(s) ? 'Rad etilgan'
        : /cancel/i.test(s) ? 'Bekor qilingan'
          : /pending/i.test(s) ? 'To‘lov kutilmoqda'
            : s
const canPay = (s: string) => /pending|reject/i.test(s)

const BTN = `inline-flex min-h-11 items-center justify-center rounded-lg px-4 text-sm font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-60 motion-reduce:transition-none ${FOCUS}`
const BTN_PRIMARY = `${BTN} bg-foreground text-[#FFFFFF] hover:bg-foreground/90 dark:bg-[#E4F70A] dark:text-foreground dark:hover:bg-[#E4F70A]/90`
const BTN_OUTLINE = `${BTN} border bg-card text-foreground hover:bg-muted`
const BTN_DANGER = `${BTN} text-error hover:bg-error/10`

const toNum = (x: unknown): number | null =>
  x === null || x === undefined || x === '' || !Number.isFinite(Number(x)) ? null : Number(x)

// Buyurtma holati: ikonka, rang va jarayon bosqichi
function orderMeta(s: string): { icon: React.ElementType; color: string; done: number; current: number; showSteps: boolean } {
  if (/approv|paid/i.test(s)) return { icon: Check, color: '#059669', done: 3, current: -1, showSteps: true }
  if (/review/i.test(s)) return { icon: Search, color: '#0284C7', done: 1, current: 1, showSteps: true }
  if (/reject/i.test(s)) return { icon: X, color: '#DC2626', done: 0, current: 0, showSteps: true }
  if (/cancel/i.test(s)) return { icon: Ban, color: '#6B7280', done: 0, current: -1, showSteps: false }
  return { icon: Clock, color: '#D97706', done: 0, current: 0, showSteps: true }
}

const STEP_LABELS = ['To‘lov', 'Tekshiruv', 'Tasdiq']

function OrderSteps({ done, current, color }: { done: number; current: number; color: string }) {
  return (
    <ol className="mt-4 grid grid-cols-3 gap-2" aria-label="Buyurtma jarayoni">
      {STEP_LABELS.map((label, i) => {
        const isDone = i < done
        const isCurrent = i === current
        return (
          <li key={label}>
            <div
              className={`h-1.5 rounded-full ${isDone ? 'bg-foreground dark:bg-[#E4F70A]' : isCurrent ? '' : 'bg-muted'}`}
              style={isCurrent ? { backgroundColor: color } : undefined}
            />
            <p className={`mt-1.5 text-[11px] ${isCurrent ? 'font-semibold text-foreground' : isDone ? 'text-muted-foreground' : 'text-muted-foreground/60'}`}>
              {label}
            </p>
          </li>
        )
      })}
    </ol>
  )
}

// Element birinchi chizilgandan keyin true bo'ladi: shu orqali 0 -> yakuniy qiymat animatsiyasi ishlaydi
function useMounted() {
  const [m, setM] = useState(false)
  useEffect(() => {
    let id2 = 0
    const id1 = requestAnimationFrame(() => {
      id2 = requestAnimationFrame(() => setM(true))
    })
    return () => {
      cancelAnimationFrame(id1)
      cancelAnimationFrame(id2)
    }
  }, [])
  return m
}

// Zina pog'onasi: pastdan o'sib chiqadi, ochilganda (obuna faol) rangga to'ladi
function Step({ h, index, filled }: { h: number; index: number; filled: boolean }) {
  const m = useMounted()
  return (
    <div className="flex flex-1 flex-col justify-end">
      <div
        className="rounded-t-xl border border-dashed transition-[height,background-color,border-color] duration-700 ease-out motion-reduce:transition-none"
        style={{
          height: m ? `${h}%` : '0%',
          transitionDelay: `${index * 110}ms`,
          backgroundColor: filled ? LIME : 'transparent',
          borderColor: m && !filled ? 'rgba(255,255,255,0.2)' : 'transparent',
        }}
      />
    </div>
  )
}

// Limit progress bari: nolldan o'sadi
function Fill({ pct, color, index }: { pct: number; color: string; index: number }) {
  const m = useMounted()
  return (
    <div
      className="h-full rounded-full transition-[width] duration-700 ease-out motion-reduce:transition-none"
      style={{ width: m ? `${pct}%` : '0%', backgroundColor: color, transitionDelay: `${150 + index * 90}ms` }}
    />
  )
}

function daysLeft(end: string) {
  return Math.max(0, Math.ceil((new Date(end).getTime() - Date.now()) / 86_400_000))
}

export default function BillingPage() {
  const sub = useApi<Sub>('/billing/me/subscription')
  const limits = useApi<BillingLimits>('/billing/me/limits')
  const plans = useApi<Plan[]>('/billing/plans')
  const products = useApi<BillingProduct[]>('/billing/products')
  const orders = useApi<Order[]>('/billing/orders?limit=25')
  const paymentInfo = useApi<PaymentRequisites>('/billing/payment-details')
  const [copiedCard, setCopiedCard] = useState(false)

  // Admin tasdig‘i boshqa sessiyada bajarilishi mumkin. Foydalanuvchi tabga qaytganda
  // kredit va buyurtma holatini yangilaymiz, eski kvotani ko‘rsatib qolmaymiz.
  useEffect(() => {
    const refreshBillingState = () => {
      void limits.reload()
      void orders.reload()
    }
    window.addEventListener('focus', refreshBillingState)
    return () => window.removeEventListener('focus', refreshBillingState)
  }, [limits.reload, orders.reload])

  const copyCard = (text: string) => {
    navigator.clipboard.writeText(text.replace(/\s+/g, ''))
    setCopiedCard(true)
    setTimeout(() => setCopiedCard(false), 3000)
  }

  const [promo, setPromo] = useState('')
  const [promoChecking, setPromoChecking] = useState(false)
  const [appliedPromo, setAppliedPromo] = useState<{ code: string; discount_amount: number; final_amount: number; discount_percent?: number | null; fixed_discount_amount?: number | null } | null>(null)
  const [promoError, setPromoError] = useState<string | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)

  // Checkout Modal State
  const [checkoutModal, setCheckoutModal] = useState<{
    orderId: string
    title: string
    amount: number
    status: string
    productType?: string
  } | null>(null)
  const [modalReceiptFile, setModalReceiptFile] = useState<File | null>(null)
  const [modalUploading, setModalUploading] = useState(false)
  const [modalSuccess, setModalSuccess] = useState(false)
  const [modalError, setModalError] = useState<string | null>(null)

  // Faol obunani bekor qilish holati
  const [cancelConfirmOpen, setCancelConfirmOpen] = useState(false)
  const [cancellingSub, setCancellingSub] = useState(false)

  async function handleCancelActiveSubscription() {
    setCancellingSub(true)
    try {
      await post('/billing/me/subscription/cancel')
      setMsg({ ok: true, text: 'Faol obuna muvaffaqiyatli bekor qilindi. Hisobingiz Free rejimiga qaytdi.' })
      sub.reload()
      limits.reload()
      orders.reload()
      setCancelConfirmOpen(false)
    } catch (e) {
      setMsg({ ok: false, text: errMsg(e) })
    } finally {
      setCancellingSub(false)
    }
  }

  async function handleSubscribe(plan: Plan) {
    const key = `buy-plan-${plan.id}`
    setBusy(key)
    setMsg(null)
    try {
      const res = await post<Order>('/billing/orders', {
        product_type: 'subscription',
        product_id: String(plan.id),
        promo_code: appliedPromo ? appliedPromo.code : undefined,
      })
      orders.reload()
      sub.reload()
      setCheckoutModal({
        orderId: res.id,
        title: res.product_title || plan.name,
        amount: res.amount,
        status: res.status,
        productType: 'subscription',
      })
      setModalReceiptFile(null)
      setModalSuccess(false)
      setModalError(null)
    } catch (e) {
      setMsg({ ok: false, text: errMsg(e) })
    } finally {
      setBusy(null)
    }
  }

  async function handleBuyProduct(product: BillingProduct) {
    const key = `buy-product-${product.id}`
    setBusy(key)
    setMsg(null)
    try {
      const res = await post<Order>('/billing/orders', {
        product_type: product.product_type,
        product_id: String(product.id),
        promo_code: appliedPromo ? appliedPromo.code : undefined,
      })
      orders.reload()
      setCheckoutModal({ orderId: res.id, title: res.product_title || product.title, amount: res.amount, status: res.status, productType: product.product_type })
      setModalReceiptFile(null)
      setModalSuccess(false)
      setModalError(null)
    } catch (e) {
      setMsg({ ok: false, text: errMsg(e) })
    } finally {
      setBusy(null)
    }
  }

  async function handleUploadModalReceipt() {
    if (!checkoutModal || !modalReceiptFile) return
    setModalUploading(true)
    setModalError(null)
    try {
      await upload(`/billing/orders/${checkoutModal.orderId}/receipt`, modalReceiptFile)
      setModalSuccess(true)
      orders.reload()
      sub.reload()
      limits.reload()
    } catch (e) {
      setModalError(errMsg(e))
    } finally {
      setModalUploading(false)
    }
  }

  async function handleApplyPromo() {
    const code = promo.trim()
    if (!code) {
      setAppliedPromo(null)
      setPromoError(null)
      return
    }
    setPromoChecking(true)
    setPromoError(null)
    try {
      const baseAmount = plans.data?.length ? Math.min(...plans.data.map((p) => Math.round(p.price * (1 - (p.discount_percent || 0) / 100)))) : 150000
      const res = await post<{ code: string; discount_amount: number; final_amount: number; discount_percent?: number | null; fixed_discount_amount?: number | null }>('/billing/promo/validate', {
        code,
        amount: baseAmount,
      })
      setAppliedPromo(res)
      setPromoError(null)
    } catch (e) {
      setAppliedPromo(null)
      setPromoError(errMsg(e))
    } finally {
      setPromoChecking(false)
    }
  }

  async function run(key: string, fn: () => Promise<unknown>, okText: string) {
    setBusy(key); setMsg(null)
    try {
      await fn()
      setMsg({ ok: true, text: okText })
      orders.reload(); sub.reload()
    } catch (e) {
      setMsg({ ok: false, text: errMsg(e) })
    } finally {
      setBusy(null)
    }
  }

  const active = !!sub.data?.is_active
  const left = active ? daysLeft(sub.data!.end_date) : 0

  return (
    <div className="space-y-8 sm:space-y-10">
      <PageHeader title="Tarif va to‘lovlar" desc="Obuna, haftalik limitlar va buyurtmalaringiz" />
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-border bg-card p-4">
        <div>
          <p className="text-sm font-semibold">To‘liq Mock Exam xarid qilmoqchimisiz?</p>
          <p className="mt-1 text-xs text-muted-foreground">Imtihon katalogi, buyurtma holati va chek yuborish alohida sahifada.</p>
        </div>
        <Link href="/dashboard/mock-exams" className="inline-flex min-h-10 items-center rounded-xl bg-foreground px-4 py-2 text-sm font-semibold text-white hover:bg-[#242428]">Mock Exam katalogi</Link>
      </div>

      {msg && (
        <div
          role="status"
          className={`flex items-start gap-3 rounded-2xl border border-border bg-white p-4 text-sm ${msg.ok
              ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
              : 'border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-400'
            }`}
        >
          <p className="flex-1">{msg.text}</p>
          <button onClick={() => setMsg(null)} aria-label="Xabarni yopish" className={`-m-1 rounded-md p-1 opacity-70 hover:opacity-100 ${FOCUS}`}>
            <X className="size-4" />
          </button>
        </div>
      )}

      {/* Obuna + limitlar */}
      <section className="grid gap-4 lg:grid-cols-5">
        {/* Sahifadagi yagona to'q panel: joriy obuna holati */}
        <div className="flex flex-col justify-between rounded-2xl p-5 sm:p-6 lg:col-span-2" style={{ backgroundColor: INK, color: '#FFFFFF' }}>
          <p className="text-sm" style={{ color: '#FFFFFFB3' }}>Joriy obuna</p>

          {/* Zinalar: Free'da faqat birinchisi ochiq, obuna faol bo'lsa hammasi to'ladi */}
          <div aria-hidden="true" className="mt-6 flex min-h-28 flex-1 items-stretch gap-2 sm:gap-3">
            {[34, 55, 77, 100].map((h, i) => (
              <Step key={h} h={h} index={i} filled={active || i === 0} />
            ))}
          </div>
          {sub.loading ? (
            <div className="mt-6 h-16 animate-pulse rounded-lg bg-white/10" />
          ) : sub.error ? (
            <p className="mt-6 text-sm" style={{ color: '#FFFFFFB3' }}>Obuna holatini yuklab bo‘lmadi.</p>
          ) : active ? (
            <div className="mt-6 space-y-3">
              <div className="flex items-center justify-between">
                <p className="flex items-center gap-2 text-sm font-medium">
                  <span className="size-2 rounded-full" style={{ backgroundColor: LIME }} aria-hidden="true" /> Faol
                </p>
                <button
                  type="button"
                  onClick={() => setCancelConfirmOpen(true)}
                  className="text-xs text-[#FFFFFF]/70 hover:text-red-400 hover:underline transition"
                >
                  Obunani bekor qilish
                </button>
              </div>
              <div>
                <p className="text-4xl font-bold tracking-tight">
                  {left} <span className="text-lg font-semibold" style={{ color: '#FFFFFFB3' }}>kun qoldi</span>
                </p>
                <p className="mt-1 text-sm" style={{ color: '#FFFFFFB3' }}>{fmtDate(sub.data!.end_date)} gacha</p>
              </div>
            </div>
          ) : (
            <div className="mt-6">
              <p className="text-2xl font-bold tracking-tight">Free tarif</p>
              <p className="mt-1 text-sm" style={{ color: '#FFFFFFB3' }}>Cheklovsiz mashq uchun tarif tanlang.</p>
              <a
                href="#plans"
                className={`mt-4 inline-flex min-h-11 items-center rounded-lg px-4 text-sm font-semibold ${FOCUS} focus-visible:ring-offset-[#0B0B0D]`}
                style={{ backgroundColor: LIME, color: INK }}
              >
                Tariflarni ko‘rish
              </a>
            </div>
          )}
        </div>

        <div className="surface p-5 sm:p-6 lg:col-span-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-sm text-muted-foreground">Haftalik limitlar</p>
              {limits.data?.week_start && (
                <p className="text-xs text-muted-foreground/80">Hafta boshi: {fmtDate(limits.data.week_start)}</p>
              )}
            </div>
            {limits.data && (
              <span className="rounded-md px-2 py-0.5 font-mono text-[11px] font-medium" style={{ backgroundColor: INK, color: LIME }}>
                {limits.data.tier}
              </span>
            )}
          </div>
          {limits.loading ? (
            <div className="mt-4 space-y-2">
              {[0, 1, 2, 3].map((i) => <div key={i} className="h-9 animate-pulse rounded-lg bg-muted" />)}
            </div>
          ) : limits.error ? (
            <p className="mt-3 text-sm text-muted-foreground">Limitlarni yuklab bo‘lmadi.</p>
          ) : (
            <>
              {limits.data?.ai && (
                <div className="mt-5 rounded-2xl border border-border bg-white p-4" aria-label="AI oylik limiti">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold">AI tekshiruv limiti</p>
                      {limits.data.month_start && (
                        <p className="mt-1 text-xs text-muted-foreground">Oy boshi: {fmtDate(limits.data.month_start)}</p>
                      )}
                      {(limits.data.ai.purchased_remaining ?? 0) > 0 && (
                        <p className="mt-1 text-xs font-medium text-emerald-600 dark:text-emerald-400">
                          Xarid qilingan Writing AI kreditlari: {limits.data.ai.purchased_remaining} ta
                        </p>
                      )}
                    </div>
                    <span className="text-sm tabular-nums text-muted-foreground">
                      {limits.data.ai.enabled
                        ? `${toNum(limits.data.ai.used_this_month) ?? 0} / ${limits.data.ai.monthly_limit ?? '∞'}`
                        : 'Faol emas'}
                    </span>
                  </div>
                  {limits.data.ai.enabled && limits.data.ai.monthly_limit !== null && limits.data.ai.monthly_limit > 0 && (
                    <div
                      role="progressbar"
                      aria-label="AI tekshiruvlar: oylik foydalanish"
                      aria-valuemin={0}
                      aria-valuemax={limits.data.ai.monthly_limit}
                      aria-valuenow={Math.min(limits.data.ai.monthly_limit, Math.max(0, toNum(limits.data.ai.used_this_month) ?? 0))}
                      className="mt-3 h-2 overflow-hidden rounded-full bg-muted"
                    >
                      <Fill
                        pct={Math.min(100, Math.round(((toNum(limits.data.ai.used_this_month) ?? 0) / limits.data.ai.monthly_limit) * 100))}
                        color={INK}
                        index={0}
                      />
                    </div>
                  )}
                  <p className="mt-1.5 text-xs text-muted-foreground">
                    {!limits.data.ai.enabled
                      ? 'Bu tarifda AI tekshiruvi yoqilmagan.'
                      : limits.data.ai.monthly_limit === null
                        ? 'Cheksiz'
                        : `${Math.max(0, toNum(limits.data.ai.remaining) ?? ((toNum(limits.data.ai.monthly_limit) ?? 0) - (toNum(limits.data.ai.used_this_month) ?? 0)))} ta qoldi`}
                  </p>
                </div>
              )}
              {limits.data?.practice && (
                <div className="mt-5 rounded-2xl border border-border bg-white p-4" aria-label="Umumiy practice limiti">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold">Barcha skilllar uchun umumiy practice limiti</p>
                      <p className="mt-1 text-xs text-muted-foreground">Reading, Listening, Writing va Speaking urinishlari umumiy kvotadan foydalanadi.</p>
                    </div>
                    <span className="shrink-0 text-sm tabular-nums text-muted-foreground">
                      {limits.data.practice.used_this_week} / {limits.data.practice.weekly_limit ?? '∞'}
                    </span>
                  </div>
                  {limits.data.practice.weekly_limit !== null && limits.data.practice.weekly_limit > 0 && (
                    <div
                      role="progressbar"
                      aria-label="Practice: haftalik umumiy foydalanish"
                      aria-valuemin={0}
                      aria-valuemax={limits.data.practice.weekly_limit}
                      aria-valuenow={Math.min(limits.data.practice.weekly_limit, Math.max(0, limits.data.practice.used_this_week))}
                      className="mt-3 h-2 overflow-hidden rounded-full bg-muted"
                    >
                      <Fill pct={Math.min(100, Math.round((limits.data.practice.used_this_week / limits.data.practice.weekly_limit) * 100))} color={INK} index={0} />
                    </div>
                  )}
                  <p className="mt-1.5 text-xs text-muted-foreground">
                    {limits.data.practice.weekly_limit === null
                      ? 'Haftalik cheklov yo‘q'
                      : `${limits.data.practice.remaining ?? Math.max(0, limits.data.practice.weekly_limit - limits.data.practice.used_this_week)} ta haftalik urinish qoldi`}
                  </p>
                  <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t pt-3 text-xs text-muted-foreground">
                    <span>Oylik sarf: {limits.data.practice.used_this_month} / {limits.data.practice.monthly_limit ?? '∞'}</span>
                    <span>{limits.data.practice.monthly_limit === null ? 'Oylik cheklov yo‘q' : `${limits.data.practice.remaining_this_month ?? Math.max(0, limits.data.practice.monthly_limit - limits.data.practice.used_this_month)} ta qoldi`}</span>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {/* Tariflar */}
      <div id="plans" className="scroll-mt-20">
        <Section title="Tariflar">
          <div className="mb-4 rounded-xl border border-dashed p-3 sm:p-4 bg-muted/20">
            <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center sm:gap-3">
              <label htmlFor="promo" className="flex items-center gap-2.5 text-sm font-medium">
                <span aria-hidden="true" className="flex size-8 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground">
                  <Ticket className="size-4" strokeWidth={1.9} />
                </span>
                Promo kodingiz bormi?
              </label>
              <div className="flex items-center gap-2 sm:ml-auto">
                <input
                  id="promo"
                  className={`${input} uppercase font-mono tracking-wider sm:max-w-[12rem]`}
                  placeholder="KODNI KIRITING"
                  value={promo}
                  onChange={(e) => {
                    setPromo(e.target.value.toUpperCase())
                    setPromoError(null)
                    if (appliedPromo && e.target.value.trim() !== appliedPromo.code) {
                      setAppliedPromo(null)
                    }
                  }}
                  autoCapitalize="characters"
                  autoComplete="off"
                />
                <button
                  type="button"
                  onClick={handleApplyPromo}
                  disabled={!promo.trim() || promoChecking}
                  className="inline-flex h-9 items-center justify-center rounded-lg border border-border bg-background px-3 text-xs font-semibold text-foreground transition hover:bg-muted disabled:opacity-50"
                >
                  {promoChecking ? 'Tekshirilmoqda…' : appliedPromo ? 'Qo‘llangan ✓' : 'Qo‘llash'}
                </button>
              </div>
            </div>

            {appliedPromo && (
              <div className="mt-2.5 flex items-center justify-between rounded-lg bg-emerald-500/10 border border-emerald-500/30 px-3 py-1.5 text-xs text-emerald-700 dark:text-emerald-400">
                <span>✓ <strong>{appliedPromo.code}</strong> kodi tekshirildi.</span>
                <span className="font-semibold">Chegirma tanlangan mahsulot summasiga qarab hisoblanadi.</span>
              </div>
            )}

            {promoError && (
              <div className="mt-2.5 rounded-lg bg-red-500/10 border border-red-500/30 px-3 py-1.5 text-xs text-red-600 dark:text-red-400">
                ✕ {promoError}
              </div>
            )}
          </div>

          {/* Obuna tariflari */}
          {plans.loading ? (
            <Loading />
          ) : plans.error ? (
            <ErrorBox message={plans.error.message} onRetry={plans.reload} />
          ) : !plans.data?.length ? (
            <Empty text="Hozircha faol tariflar yo‘q." />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {plans.data.map((plan) => {
                const key = `buy-plan-${plan.id}`
                const includedSkills = plan.included_skills || (plan.tier === 'pro' ? ['READING', 'LISTENING', 'WRITING', 'SPEAKING'] : ['READING', 'LISTENING', 'WRITING'])
                const hasSpeaking = includedSkills.includes('SPEAKING')
                const discountedPrice = Math.round(plan.price * (1 - (plan.discount_percent || 0) / 100))
                const promoDiscount = appliedPromo
                  ? appliedPromo.discount_percent != null
                    ? Math.round(discountedPrice * appliedPromo.discount_percent / 100)
                    : Math.min(discountedPrice, appliedPromo.fixed_discount_amount ?? appliedPromo.discount_amount ?? 0)
                  : 0
                const finalPlanPrice = Math.max(0, discountedPrice - promoDiscount)

                // ✅ Declare both isPlus and isPro here based on plan.tier
                const isPlus = plan.tier === 'plus'
                const isPro = plan.tier === 'pro'

                return (
                  <div key={plan.id} className="surface flex min-w-0 flex-col justify-between overflow-hidden border">
                    <div className="p-5 sm:p-6">
                      <div className="mb-3 flex items-center justify-between gap-2">
                        <span
                          className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-bold uppercase tracking-wider ${isPro
                              ? 'bg-purple-500/15 text-purple-700 border border-purple-500/30 dark:text-purple-400'
                              : isPlus
                                ? 'bg-[#E4F70A]/20 text-foreground border border-foreground/15'
                                : 'bg-muted text-muted-foreground'
                            }`}
                        >
                          <Sparkles className="size-3" /> {plan.tier}
                        </span>
                        <span className="shrink-0 text-xs text-muted-foreground">{plan.duration_days === 30 ? '1 oy' : plan.duration_days === 90 ? '3 oy' : plan.duration_days === 365 ? '1 yil' : `${plan.duration_days} kun`}</span>
                      </div>

                      <h3 className="text-lg font-bold tracking-tight text-foreground">{plan.name}</h3>
                      {plan.description && <p className="mt-1.5 text-sm leading-5 text-muted-foreground">{plan.description}</p>}

                      <div className="mt-5 flex flex-wrap items-baseline gap-x-2 gap-y-1">
                        <span className="text-2xl font-black tracking-tight text-foreground sm:text-3xl">{fmtMoney(finalPlanPrice)}</span>
                        {((plan.discount_percent ?? 0) > 0 || promoDiscount > 0) && <span className="text-sm text-muted-foreground line-through">{fmtMoney(plan.price)}</span>}
                      </div>
                      {promoDiscount > 0 && <p className="mt-1 text-xs font-semibold text-emerald-700 dark:text-emerald-400">Promo chegirma: −{fmtMoney(promoDiscount)}</p>}
                      {(plan.discount_percent || 0) > 0 && <p className="mt-1 text-xs text-muted-foreground">Tarif chegirmasi: {plan.discount_percent}%</p>}

                      <div className="my-5 border-t border-border" />
                      <p className="mb-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">Tarif tarkibi</p>
                      <ul className="space-y-2.5 text-sm text-foreground">
                        {includedSkills.map((skill) => (
                          <li key={skill} className="flex items-start gap-2">
                            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-emerald-600" />
                            <span>{({ READING: 'Reading', LISTENING: 'Listening', WRITING: 'Writing', SPEAKING: 'Speaking' } as Record<string, string>)[skill] || skill}</span>
                          </li>
                        ))}
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-emerald-600" />
                          <span>{plan.ai_enabled && plan.ai_limit > 0 ? `Writing AI tekshiruvi: ${plan.ai_limit} ta / oy` : 'Writing AI tekshiruvi kiritilmagan'}</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-emerald-600" />
                          <span>{hasSpeaking ? 'Speaking mashqlari kiritilgan' : 'Speaking mashqlari bu tarifga kirmaydi'}</span>
                        </li>
                      </ul>
                    </div>
                    <div className="border-t border-border bg-muted/20 p-5 sm:p-6">
                      <button
                        type="button"
                        onClick={() => void handleSubscribe(plan)}
                        disabled={busy !== null}
                        className={`${BTN_PRIMARY} w-full gap-2`}
                      >
                        {busy === key ? <Clock className="size-4 animate-pulse" /> : <CreditCard className="size-4" />}
                        {busy === key ? 'Buyurtma yaratilmoqda…' : 'Obunani sotib olish'}
                      </button>
                      <p className="mt-2 text-center text-[11px] leading-4 text-muted-foreground">Chek yuborilgach, admin tasdig‘i bilan faollashadi.</p>
                    </div>
                  </div>
                )
              })}
            </div>
          )}

        </Section>
      </div>

      {/* To'lov uchun rasmiy rekvizitlar */}
      {(() => {
        const cardNum = paymentInfo.data?.card_number || ''
        const cardHolder = paymentInfo.data?.card_holder || ''
        const bankName = paymentInfo.data?.bank_name || ''
        const accNum = paymentInfo.data?.account_number || ''
        const phoneNum = paymentInfo.data?.phone_number || ''
        const instructions =
          paymentInfo.data?.instructions ||
          "To'lov rekvizitlari administrator tomonidan hali sozlanmagan. Rekvizitlar tasdiqlanmaguncha to'lov qilmang."

        return (
          <div className="surface overflow-hidden rounded-2xl border p-5 sm:p-7 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-5 border-b">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="flex size-7 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <CreditCard className="size-4" />
                  </span>
                  <h3 className="text-base font-bold text-foreground">To‘lov uchun rasmiy rekvizitlar</h3>
                </div>
                <p className="text-xs text-muted-foreground">
                  Obuna yoki testlar uchun to‘lovni quyidagi karta raqamiga o‘tkazing va chekni yuklang
                </p>
              </div>

              <button
                type="button"
                disabled={!cardNum}
                onClick={() => cardNum && copyCard(cardNum)}
                className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground shadow-xs transition-all hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {copiedCard ? <CheckCheck className="size-4 text-emerald-400" /> : <Copy className="size-4" />}
                {copiedCard ? 'Karta nusxalandi!' : 'Karta raqamini nusxalash'}
              </button>
            </div>

            <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-5">
              {/* Karta dizayni */}
              <div className="rounded-2xl bg-foreground text-[#FFFFFF] p-5 flex flex-col justify-between shadow-md">
                <div>
                  <div className="flex items-center justify-between">
                    <p className="text-[11px] font-semibold uppercase tracking-wider text-[#FFFFFF]/70">
                      Uzcard / Humo
                    </p>
                    <span className="text-[10px] uppercase font-bold text-[#E4F70A] tracking-wider">
                      {bankName}
                    </span>
                  </div>
                  <p className="mt-4 break-all font-mono text-xl font-bold tracking-wider text-[#FFFFFF]">
                    {cardNum || 'Karta raqami sozlanmagan'}
                  </p>
                </div>
                <div className="mt-6 flex items-center justify-between text-xs text-[#FFFFFF]/80">
                  <span className="truncate">{cardHolder || 'Karta egasi sozlanmagan'}</span>
                  <span className="text-[10px] text-muted-foreground text-[#FFFFFF]/50">Official</span>
                </div>
              </div>

              {/* Rekvizitlar tafsiloti */}
              <div className="space-y-3 text-xs md:col-span-2 flex flex-col justify-center">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div className="p-3 rounded-xl bg-muted/40 border">
                    <span className="text-muted-foreground block text-[11px]">Karta egasi:</span>
                    <strong className="text-xs font-semibold text-foreground">{cardHolder || 'Sozlanmagan'}</strong>
                  </div>
                  <div className="p-3 rounded-xl bg-muted/40 border">
                    <span className="text-muted-foreground block text-[11px]">Bank:</span>
                    <strong className="text-xs font-semibold text-foreground">{bankName || 'Sozlanmagan'}</strong>
                  </div>
                  {phoneNum && (
                    <div className="p-3 rounded-xl bg-muted/40 border">
                      <span className="text-muted-foreground block text-[11px]">Click / Payme telefon:</span>
                      <strong className="text-xs font-mono font-semibold text-foreground">{phoneNum}</strong>
                    </div>
                  )}
                  {accNum && (
                    <div className="p-3 rounded-xl bg-muted/40 border">
                      <span className="text-muted-foreground block text-[11px]">Hisob raqam:</span>
                      <strong className="text-xs font-mono font-semibold text-foreground">{accNum}</strong>
                    </div>
                  )}
                </div>

                <div className={`rounded-2xl border border-border bg-white p-3 text-xs leading-relaxed ${cardNum ? 'bg-muted/20 text-muted-foreground' : 'border-red-500/30 bg-red-500/10 text-red-700 dark:text-red-300'}`}>
                  <strong>{cardNum ? 'To‘lov ko‘rsatmasi:' : 'To‘lov hozircha mavjud emas:'}</strong> {instructions}
                </div>
              </div>
            </div>
          </div>
        )
      })()}

      {products.data?.some(product => product.is_active && ['full_exam', 'writing_ai_credits', 'teacher_review_credits'].includes(product.product_type)) ? (
        <Section title="Alohida xizmatlar va testlar">
          <p className="mb-4 text-sm text-muted-foreground">Writing AI qo‘shimcha tekshiruv kreditlari yoki alohida Full Exam mahsulotlarini xarid qiling. Huquq to‘lov tasdiqlangandan keyin faollashadi.</p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {products.data.filter(product => product.is_active && ['full_exam', 'writing_ai_credits', 'teacher_review_credits'].includes(product.product_type)).map(product => (
              <article key={product.id} className="surface flex flex-col justify-between border p-5">
                <div>
                  <h3 className="font-bold">{product.title}</h3>
                  {product.description ? <p className="mt-2 text-sm text-muted-foreground">{product.description}</p> : null}
                  <p className="mt-4 text-lg font-black">{product.price.toLocaleString('uz-UZ')} UZS</p>
                  <p className="text-xs text-muted-foreground">{product.product_type === 'writing_ai_credits' ? `Writing AI qo‘shimcha kreditlari · ${product.external_ref || '?'} ta tekshiruv` : product.product_type === 'teacher_review_credits' ? `Ustoz tekshiruvi kreditlari · ${product.external_ref || '?'} ta tekshiruv` : 'Bir martalik test xaridi'}</p>
                </div>
                <button type="button" disabled={!!busy} onClick={() => handleBuyProduct(product)} className={`${BTN_PRIMARY} mt-4 w-full`}>
                  {busy === `buy-product-${product.id}` ? 'Tayyorlanmoqda…' : 'Xarid qilish'}
                </button>
              </article>
            ))}
          </div>
        </Section>
      ) : null}

      {/* Buyurtmalar */}
      <Section title="Buyurtmalarim">
        {orders.loading ? <Loading rows={1} /> : orders.error ? <ErrorBox message={orders.error.message} onRetry={orders.reload} /> : !orders.data?.length ? <Empty text="Hali buyurtma yo‘q." /> : (
          <ul className="space-y-3">
            {orders.data.map((o) => {
              const pay = canPay(o.status)
              const rejected = /reject/i.test(o.status)
              const meta = orderMeta(o.status)
              return (
                <li key={o.id} className="surface p-4 sm:p-5">
                  <div className="flex items-start gap-3">
                    <span
                      aria-hidden="true"
                      className="flex size-10 shrink-0 items-center justify-center rounded-xl"
                      style={{ backgroundColor: `${meta.color}1F`, color: meta.color }}
                    >
                      <meta.icon className="size-5" strokeWidth={2} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                        <p className="truncate font-semibold">{o.product_title || 'Buyurtma'}</p>
                        <Badge tone={orderTone(o.status)}>{orderLabel(o.status)}</Badge>
                      </div>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {fmtDate(o.created_at)} · <span className="font-mono">#{String(o.id).slice(0, 8)}</span>
                      </p>
                    </div>
                    <div className="shrink-0 text-right">
                      <p className="font-semibold tabular-nums">{fmtMoney(o.amount)}</p>
                      {!!o.discount_amount && (
                        <p className="text-xs text-emerald-600 dark:text-emerald-400">−{fmtMoney(o.discount_amount)}</p>
                      )}
                    </div>
                  </div>

                  {meta.showSteps && <OrderSteps done={meta.done} current={meta.current} color={meta.color} />}

                  {pay && (
                    <div className="mt-4 flex flex-col gap-2 border-t pt-4 sm:flex-row sm:items-center">
                      <p className={`flex-1 text-sm ${rejected ? 'font-medium text-error' : 'text-muted-foreground'}`}>
                        {rejected ? 'Chek rad etildi. Yangi chek yuklang.' : 'To‘lovdan so‘ng chekni yuklang, buyurtma tekshiriladi.'}
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setCheckoutModal({
                            orderId: o.id,
                            title: o.product_title || 'Buyurtma',
                            amount: o.amount,
                            status: o.status,
                            productType: o.product_type,
                          })
                          setModalReceiptFile(null)
                          setModalSuccess(false)
                          setModalError(null)
                        }}
                        className={`${BTN_PRIMARY} text-xs`}
                      >
                        <CreditCard className="size-3.5 mr-1.5" /> To‘lov va Chek yuklash
                      </button>
                      <button
                        className={BTN_DANGER}
                        disabled={busy === `c-${o.id}`}
                        onClick={() => run(`c-${o.id}`, () => post(`/billing/orders/${o.id}/cancel`), 'Buyurtma bekor qilindi.')}
                      >
                        {busy === `c-${o.id}` ? 'Bekor qilinmoqda…' : 'Bekor qilish'}
                      </button>
                    </div>
                  )}
                </li>
              )
            })}
          </ul>
        )}
      </Section>

      {/* ── TO‘LOV VA CHEK YUKLASH MODALI (CHECKOUT MODAL) ── */}
      {checkoutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-lg rounded-3xl border border-border bg-card p-6 sm:p-7 shadow-2xl animate-in fade-in zoom-in-95 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-border">
              <div>
                <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
                  <CreditCard className="size-5 text-primary" /> To‘lov va Rekvizitlar
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Buyurtma <span className="font-mono font-semibold">#{checkoutModal.orderId.slice(0, 8)}</span> · {checkoutModal.title}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setCheckoutModal(null)}
                className="rounded-xl p-1.5 text-muted-foreground hover:bg-muted transition"
              >
                <X className="size-5" />
              </button>
            </div>

            <div className="mt-5 space-y-5">
              {/* To'lov summasi */}
              <div className="rounded-2xl bg-muted/40 border border-border/80 p-4 flex items-center justify-between">
                <span className="text-xs font-medium text-muted-foreground">To‘lov summasi:</span>
                <span className="font-mono text-2xl font-black text-foreground">
                  {fmtMoney(checkoutModal.amount)}
                </span>
              </div>

              {/* Karta va Rekvizitlar */}
              {(() => {
                const cNum = paymentInfo.data?.card_number || ''
                const cHolder = paymentInfo.data?.card_holder || ''
                const bName = paymentInfo.data?.bank_name || ''
                const pPhone = paymentInfo.data?.phone_number || ''
                const pInst = paymentInfo.data?.instructions || "To'lov rekvizitlari administrator tomonidan sozlanmagan. Rekvizitlar tasdiqlanmaguncha to'lov qilmang."

                return (
                  <div className="space-y-3">
                    {/* Karta dizayni */}
                    <div className="rounded-2xl bg-foreground text-[#FFFFFF] p-5 shadow-lg space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-[#FFFFFF]/70">
                          Uzcard / Humo
                        </span>
                        <span className="text-[10px] font-bold text-[#E4F70A] uppercase tracking-wider">
                          {bName}
                        </span>
                      </div>

                      <div className="flex items-center justify-between gap-3">
                        <p className="font-mono text-xl sm:text-2xl font-bold tracking-wider text-[#FFFFFF]">
                          {cNum || 'Karta raqami sozlanmagan'}
                        </p>
                        <button
                          type="button"
                          onClick={() => cNum && copyCard(cNum)}
                          disabled={!cNum}
                          className="inline-flex shrink-0 items-center gap-1.5 rounded-lg bg-white/10 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-white/20 disabled:cursor-not-allowed disabled:opacity-40"
                        >
                          {copiedCard ? <CheckCheck className="size-3.5 text-emerald-400" /> : <Copy className="size-3.5" />}
                          {copiedCard ? 'Nusxalandi' : 'Nusxalash'}
                        </button>
                      </div>

                      <div className="flex items-center justify-between text-xs text-[#FFFFFF]/80 pt-2 border-t border-white/10">
                        <span className="truncate">{cHolder || 'Karta egasi sozlanmagan'}</span>
                        {pPhone && <span className="font-mono text-[11px] text-[#FFFFFF]/60">{pPhone}</span>}
                      </div>
                    </div>

                    <div className={`p-3 rounded-xl border text-xs leading-relaxed ${cNum ? 'bg-amber-500/10 border-amber-500/20 text-amber-800 dark:text-amber-300' : 'bg-red-500/10 border-red-500/30 text-red-700 dark:text-red-300'}`}>
                      <strong>{cNum ? 'Eslatma:' : 'To‘lov hozircha mavjud emas:'}</strong> {pInst}
                    </div>
                  </div>
                )
              })()}

              {/* Chek yuklash bosqichi */}
              <div className="border-t border-border pt-4 space-y-3">
                <p className="text-xs font-bold text-foreground uppercase tracking-wider">
                  To‘lov chekini (kvitansiya) yuklash:
                </p>

                {modalSuccess ? (
                  <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-center space-y-2">
                    <CheckCircle2 className="size-8 text-emerald-600 dark:text-emerald-400 mx-auto" />
                    <p className="text-sm font-bold text-emerald-800 dark:text-emerald-300">
                      Chek muvaffaqiyatli qabul qilindi!
                    </p>
                    <p className="text-xs text-emerald-700/80 dark:text-emerald-300/80">
                      Chek tekshiruvga yuborildi. {checkoutModal.productType === 'writing_ai_credits' ? 'AI kreditlari' : checkoutModal.productType === 'teacher_review_credits' ? 'Ustoz tekshiruvi kreditlari' : checkoutModal.productType === 'full_exam' || checkoutModal.productType === 'mock_exam' ? 'Testga kirish huquqi' : 'Obuna'} administrator to‘lovni tasdiqlagandan keyin faollashadi. Holatni Buyurtmalarim bo‘limida kuzatishingiz mumkin.
                    </p>
                    <button
                      type="button"
                      onClick={() => setCheckoutModal(null)}
                      className="mt-2 inline-flex items-center rounded-xl bg-emerald-600 px-4 py-2 text-xs font-semibold text-white hover:bg-emerald-700 transition"
                    >
                      Tushundim, yopish
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <label className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-border hover:border-primary/60 bg-muted/20 p-5 cursor-pointer transition">
                      <CreditCard className="size-6 text-muted-foreground mb-1" />
                      <span className="text-xs font-semibold text-foreground">
                        {modalReceiptFile ? modalReceiptFile.name : 'Chek faylini tanlang (JPG, PNG, PDF)'}
                      </span>
                      <span className="text-[10px] text-muted-foreground mt-0.5">
                        {modalReceiptFile ? `${(modalReceiptFile.size / 1024).toFixed(1)} KB` : 'Maksimal hajm: 8 MB'}
                      </span>
                      <input
                        type="file"
                        accept="image/*,application/pdf"
                        className="sr-only"
                        onChange={e => {
                          const f = e.target.files?.[0]
                          if (f) {
                            setModalReceiptFile(f)
                            setModalError(null)
                          }
                        }}
                      />
                    </label>

                    {modalError && (
                      <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-2.5 text-xs text-red-600 dark:text-red-400">
                        ✕ {modalError}
                      </div>
                    )}

                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setCheckoutModal(null)}
                        className="rounded-xl border border-border px-4 py-2 text-xs font-semibold text-foreground hover:bg-muted"
                      >
                        Keyinroq
                      </button>
                      <button
                        type="button"
                        disabled={!modalReceiptFile || modalUploading}
                        onClick={handleUploadModalReceipt}
                        className={`${BTN_PRIMARY} text-xs disabled:opacity-50`}
                      >
                        {modalUploading ? 'Yuklanmoqda…' : 'Chekni tasdiqlashga yuborish'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── OBUNANI BEKOR QILISH TASDIQ MODALI ── */}
      {cancelConfirmOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="w-full max-w-md rounded-3xl border border-border bg-card p-6 shadow-2xl animate-in fade-in zoom-in-95 space-y-4">
            <div className="flex items-start gap-3">
              <span className="flex size-10 shrink-0 items-center justify-center rounded-2xl bg-red-500/10 text-red-600 dark:text-red-400">
                <Ban className="size-5" />
              </span>
              <div>
                <h3 className="text-base font-bold text-foreground">Faol obunani bekor qilish</h3>
                <p className="mt-1 text-xs text-muted-foreground leading-relaxed">
                  Haqiqatan ham faol obunangizni bekor qilmoqchimisiz? Bekor qilingandan so‘ng hisobingiz darhol Free (bepul) rejimiga qaytadi va obunaning qolgan muddati to‘xtatiladi.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-border">
              <button
                type="button"
                disabled={cancellingSub}
                onClick={() => setCancelConfirmOpen(false)}
                className="rounded-xl border border-border px-4 py-2 text-xs font-semibold text-foreground hover:bg-muted transition"
              >
                Orqaga (qoldirish)
              </button>
              <button
                type="button"
                disabled={cancellingSub}
                onClick={handleCancelActiveSubscription}
                className="rounded-xl bg-red-600 hover:bg-red-700 px-4 py-2 text-xs font-semibold text-white transition disabled:opacity-50"
              >
                {cancellingSub ? 'Bekor qilinmoqda…' : 'Ha, obunani bekor qilish'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}