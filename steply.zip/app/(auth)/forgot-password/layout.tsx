import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Parolni tiklash',
  description: "Steply hisobingiz parolini tiklang.",
  robots: { index: false, follow: false },
}

export default function ForgotPasswordLayout({ children }: { children: React.ReactNode }) {
  return children
}
